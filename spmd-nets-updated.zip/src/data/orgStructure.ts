export type NetsUnitType =
  | "company"
  | "board"
  | "director"
  | "department"
  | "branch"
  | "division"
  | "section"
  | "project"
  | "subsystem"
  | "position";

export interface NetsUnit {
  id: string;
  parentId: string | null;
  type: NetsUnitType;
  nameTj: string;
  nameRu?: string | null;
  path: string[];
  headcount: number;
  positionCount: number;
  salary: number;
  fmm: number;
  totalSalary: number;
  sourceRow?: number;
}

export const units: NetsUnit[] = [
  {
    "id": "board",
    "parentId": null,
    "type": "board",
    "nameTj": "Шӯрои нозирон",
    "nameRu": "Наблюдательный совет",
    "path": [
      "Шӯрои нозирон"
    ],
    "headcount": 320.0,
    "positionCount": 195,
    "salary": 1093160.13,
    "fmm": 1093280.13,
    "totalSalary": 724197.63
  },
  {
    "id": "general-director",
    "parentId": "board",
    "type": "director",
    "nameTj": "Директори генералӣ",
    "nameRu": "Генеральный директор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ"
    ],
    "headcount": 320.0,
    "positionCount": 195,
    "salary": 1093160.13,
    "fmm": 1093280.13,
    "totalSalary": 724197.63
  },
  {
    "id": "mamuriyat-6",
    "parentId": "general-director",
    "type": "division",
    "nameTj": "Маъмурият",
    "nameRu": "Администрация",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Маъмурият"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 12000.0,
    "fmm": 12000.0,
    "totalSalary": 12000.0,
    "sourceRow": 6
  },
  {
    "id": "position-direktori-generali-7",
    "parentId": "mamuriyat-6",
    "type": "position",
    "nameTj": "Директори генералӣ",
    "nameRu": "Генеральный директор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Маъмурият",
      "Директори генералӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 12000.0,
    "fmm": 12000.0,
    "totalSalary": 12000.0,
    "sourceRow": 7
  },
  {
    "id": "departamenti-tijorati-9",
    "parentId": "general-director",
    "type": "department",
    "nameTj": "Департаменти тиҷоратӣ",
    "nameRu": "Коммерческий департамент",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ"
    ],
    "headcount": 49.0,
    "positionCount": 28,
    "salary": 171560.13,
    "fmm": 171560.13,
    "totalSalary": 98077.63,
    "sourceRow": 9
  },
  {
    "id": "position-direktori-tijorati-10",
    "parentId": "departamenti-tijorati-9",
    "type": "position",
    "nameTj": "Директори тиҷоратӣ",
    "nameRu": "Коммерческий директор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Директори тиҷоратӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 8100.0,
    "fmm": 8100.0,
    "totalSalary": 8100.0,
    "sourceRow": 10
  },
  {
    "id": "position-menejeri-loihahoi-tijorati-11",
    "parentId": "departamenti-tijorati-9",
    "type": "position",
    "nameTj": "Менеҷери лоиҳаҳои тиҷоратӣ",
    "nameRu": "Менеджер коммерческих проектов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Менеҷери лоиҳаҳои тиҷоратӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 4620.0,
    "sourceRow": 11
  },
  {
    "id": "position-tahlilgari-tijorati-12",
    "parentId": "departamenti-tijorati-9",
    "type": "position",
    "nameTj": "Таҳлилгари тиҷоратӣ",
    "nameRu": "Коммерческий аналитик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Таҳлилгари тиҷоратӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3000.0,
    "sourceRow": 12
  },
  {
    "id": "shubai-kor-bo-bozori-tijorati-13",
    "parentId": "departamenti-tijorati-9",
    "type": "division",
    "nameTj": "Шуъбаи кор бо бозори тиҷоратӣ",
    "nameRu": "Отдел по работе с бизнес-рынком",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи кор бо бозори тиҷоратӣ"
    ],
    "headcount": 8.0,
    "positionCount": 6,
    "salary": 31000.0,
    "fmm": 31000.0,
    "totalSalary": 21340.0,
    "sourceRow": 13
  },
  {
    "id": "position-sardori-shuba-14",
    "parentId": "shubai-kor-bo-bozori-tijorati-13",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи кор бо бозори тиҷоратӣ",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 4620.0,
    "sourceRow": 14
  },
  {
    "id": "position-mutahassis-oid-ba-kor-bo-bozori-tijorati-15",
    "parentId": "shubai-kor-bo-bozori-tijorati-13",
    "type": "position",
    "nameTj": "Мутахассис оид ба кор бо бозори тиҷоратӣ",
    "nameRu": "Специалист по работе с бизнес-рынком",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи кор бо бозори тиҷоратӣ",
      "Мутахассис оид ба кор бо бозори тиҷоратӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3460.0,
    "sourceRow": 15
  },
  {
    "id": "position-menejer-oid-ba-hizmatrasoni-ba-mizojoni-korporativi-16",
    "parentId": "shubai-kor-bo-bozori-tijorati-13",
    "type": "position",
    "nameTj": "Менеҷер оид ба хизматрасонӣ ба мизоҷони корпоративӣ",
    "nameRu": "Менеджер по обслуживанию корпоративных клиентов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи кор бо бозори тиҷоратӣ",
      "Менеҷер оид ба хизматрасонӣ ба мизоҷони корпоративӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 3460.0,
    "sourceRow": 16
  },
  {
    "id": "position-menejer-oid-ba-avtomatikunonii-crm-17",
    "parentId": "shubai-kor-bo-bozori-tijorati-13",
    "type": "position",
    "nameTj": "Менеҷер оид ба автоматикунонии CRM",
    "nameRu": "Менеджер по автоматизации CRM",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи кор бо бозори тиҷоратӣ",
      "Менеҷер оид ба автоматикунонии CRM"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 3460.0,
    "sourceRow": 17
  },
  {
    "id": "position-mamuri-sistemavi-18",
    "parentId": "shubai-kor-bo-bozori-tijorati-13",
    "type": "position",
    "nameTj": "Маъмури системавӣ",
    "nameRu": "Системный администратор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи кор бо бозори тиҷоратӣ",
      "Маъмури системавӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 2880.0,
    "sourceRow": 18
  },
  {
    "id": "position-menejer-oid-ba-furush-19",
    "parentId": "shubai-kor-bo-bozori-tijorati-13",
    "type": "position",
    "nameTj": "Менеҷер оид ба фурӯш",
    "nameRu": "Менеджер по продажам",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи кор бо бозори тиҷоратӣ",
      "Менеҷер оид ба фурӯш"
    ],
    "headcount": 3.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 12000.0,
    "totalSalary": 3460.0,
    "sourceRow": 19
  },
  {
    "id": "shubai-marketing-20",
    "parentId": "departamenti-tijorati-9",
    "type": "division",
    "nameTj": "Шуъбаи маркетинг",
    "nameRu": "Отдел маркетинга",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи маркетинг"
    ],
    "headcount": 3.0,
    "positionCount": 3,
    "salary": 12000.0,
    "fmm": 12000.0,
    "totalSalary": 9220.0,
    "sourceRow": 20
  },
  {
    "id": "position-sardori-shuba-21",
    "parentId": "shubai-marketing-20",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи маркетинг",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 3460.0,
    "sourceRow": 21
  },
  {
    "id": "position-menejer-oid-ba-reklama-22",
    "parentId": "shubai-marketing-20",
    "type": "position",
    "nameTj": "Менеҷер оид ба реклама",
    "nameRu": "Менеджер по рекламе",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи маркетинг",
      "Менеҷер оид ба реклама"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 2880.0,
    "sourceRow": 22
  },
  {
    "id": "position-mutahassis-oid-ba-marketingi-loihaho-23",
    "parentId": "shubai-marketing-20",
    "type": "position",
    "nameTj": "Мутахассис оид ба маркетинги лоиҳаҳо",
    "nameRu": "Специалист по маркетингу проектов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи маркетинг",
      "Мутахассис оид ба маркетинги лоиҳаҳо"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 2880.0,
    "sourceRow": 23
  },
  {
    "id": "shubai-furush-24",
    "parentId": "departamenti-tijorati-9",
    "type": "division",
    "nameTj": "Шуъбаи фурӯш",
    "nameRu": "Отдел продаж",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи фурӯш"
    ],
    "headcount": 4.0,
    "positionCount": 3,
    "salary": 17200.0,
    "fmm": 17200.0,
    "totalSalary": 10380.0,
    "sourceRow": 24
  },
  {
    "id": "position-sardori-shuba-25",
    "parentId": "shubai-furush-24",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи фурӯш",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 4620.0,
    "sourceRow": 25
  },
  {
    "id": "position-menejeri-kalon-26",
    "parentId": "shubai-furush-24",
    "type": "position",
    "nameTj": "Менеҷери калон",
    "nameRu": "Старший менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи фурӯш",
      "Менеҷери калон"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4200.0,
    "fmm": 4200.0,
    "totalSalary": 2880.0,
    "sourceRow": 26
  },
  {
    "id": "position-menejer-oid-ba-furush-27",
    "parentId": "shubai-furush-24",
    "type": "position",
    "nameTj": "Менеҷер оид ба фурӯш",
    "nameRu": "Менеджер по продажам",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи фурӯш",
      "Менеҷер оид ба фурӯш"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 8000.0,
    "totalSalary": 2880.0,
    "sourceRow": 27
  },
  {
    "id": "shubai-hizmatrasonii-mizojon-28",
    "parentId": "departamenti-tijorati-9",
    "type": "division",
    "nameTj": "Шуъбаи хизматрасонии мизоҷон",
    "nameRu": "Отдел обслуживания клиентов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷон"
    ],
    "headcount": 12.0,
    "positionCount": 6,
    "salary": 32800.0,
    "fmm": 32800.0,
    "totalSalary": 17280.0,
    "sourceRow": 28
  },
  {
    "id": "position-sardori-shuba-29",
    "parentId": "shubai-hizmatrasonii-mizojon-28",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷон",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 4620.0,
    "sourceRow": 29
  },
  {
    "id": "position-mamuri-sistemavi-30",
    "parentId": "shubai-hizmatrasonii-mizojon-28",
    "type": "position",
    "nameTj": "Маъмури системавӣ",
    "nameRu": "Системный администратор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷон",
      "Маъмури системавӣ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 2880.0,
    "sourceRow": 30
  },
  {
    "id": "position-mamuri-sistemavii-shabona-31",
    "parentId": "shubai-hizmatrasonii-mizojon-28",
    "type": "position",
    "nameTj": "Маъмури системавии шабона",
    "nameRu": "Ночной системный администратор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷон",
      "Маъмури системавии шабона"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 2880.0,
    "sourceRow": 31
  },
  {
    "id": "position-operatori-shabona-32",
    "parentId": "shubai-hizmatrasonii-mizojon-28",
    "type": "position",
    "nameTj": "Оператори шабона",
    "nameRu": "Ночной оператор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷон",
      "Оператори шабона"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 2300.0,
    "fmm": 4600.0,
    "totalSalary": 2300.0,
    "sourceRow": 32
  },
  {
    "id": "position-operator-33",
    "parentId": "shubai-hizmatrasonii-mizojon-28",
    "type": "position",
    "nameTj": "Оператор",
    "nameRu": "Оператор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷон",
      "Оператор"
    ],
    "headcount": 4.0,
    "positionCount": 1,
    "salary": 2300.0,
    "fmm": 9200.0,
    "totalSalary": 2300.0,
    "sourceRow": 33
  },
  {
    "id": "position-mushovir-oid-ba-kor-bo-mizojon-dar-shabakahoi-ijtimoi-3",
    "parentId": "shubai-hizmatrasonii-mizojon-28",
    "type": "position",
    "nameTj": "Мушовир оид ба кор бо мизоҷон дар шабакаҳои иҷтимоӣ",
    "nameRu": "Консультант по работе с клиентами в социальных сетях",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷон",
      "Мушовир оид ба кор бо мизоҷон дар шабакаҳои иҷтимоӣ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 5000.0,
    "totalSalary": 2300.0,
    "sourceRow": 34
  },
  {
    "id": "shubai-hizmatrasonii-mizojoni-loiha-35",
    "parentId": "departamenti-tijorati-9",
    "type": "division",
    "nameTj": "Шуъбаи хизматрасонии мизоҷони лоиҳа",
    "nameRu": "Отдел обслуживания клиентов проекта",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷони лоиҳа"
    ],
    "headcount": 19.0,
    "positionCount": 7,
    "salary": 63460.13,
    "fmm": 63460.13,
    "totalSalary": 24137.63,
    "sourceRow": 35
  },
  {
    "id": "position-sardori-shuba-36",
    "parentId": "shubai-hizmatrasonii-mizojoni-loiha-35",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷони лоиҳа",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 4620.0,
    "sourceRow": 36
  },
  {
    "id": "position-operatori-kalon-37",
    "parentId": "shubai-hizmatrasonii-mizojoni-loiha-35",
    "type": "position",
    "nameTj": "Оператори калон",
    "nameRu": "Старший оператор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷони лоиҳа",
      "Оператори калон"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5197.12,
    "fmm": 5197.12,
    "totalSalary": 5197.12,
    "sourceRow": 37
  },
  {
    "id": "position-operatori-ftf-38",
    "parentId": "shubai-hizmatrasonii-mizojoni-loiha-35",
    "type": "position",
    "nameTj": "Оператори FTF",
    "nameRu": "Оператор FTF",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷони лоиҳа",
      "Оператори FTF"
    ],
    "headcount": 3.0,
    "positionCount": 1,
    "salary": 4617.35,
    "fmm": 13852.050000000001,
    "totalSalary": 4617.35,
    "sourceRow": 38
  },
  {
    "id": "position-operator-39",
    "parentId": "shubai-hizmatrasonii-mizojoni-loiha-35",
    "type": "position",
    "nameTj": "Оператор",
    "nameRu": "Оператор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷони лоиҳа",
      "Оператор"
    ],
    "headcount": 4.0,
    "positionCount": 1,
    "salary": 2970.78,
    "fmm": 11883.12,
    "totalSalary": 2970.78,
    "sourceRow": 39
  },
  {
    "id": "position-operatori-shabona-40",
    "parentId": "shubai-hizmatrasonii-mizojoni-loiha-35",
    "type": "position",
    "nameTj": "Оператори шабона",
    "nameRu": "Ночной оператор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷони лоиҳа",
      "Оператори шабона"
    ],
    "headcount": 8.0,
    "positionCount": 1,
    "salary": 2970.78,
    "fmm": 23766.24,
    "totalSalary": 2970.78,
    "sourceRow": 40
  },
  {
    "id": "position-tehnik-41",
    "parentId": "shubai-hizmatrasonii-mizojoni-loiha-35",
    "type": "position",
    "nameTj": "Техник",
    "nameRu": "Техник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷони лоиҳа",
      "Техник"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2970.78,
    "fmm": 2970.78,
    "totalSalary": 2970.78,
    "sourceRow": 41
  },
  {
    "id": "position-farrosh-42",
    "parentId": "shubai-hizmatrasonii-mizojoni-loiha-35",
    "type": "position",
    "nameTj": "Фаррош",
    "nameRu": "Уборщица",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти тиҷоратӣ",
      "Шуъбаи хизматрасонии мизоҷони лоиҳа",
      "Фаррош"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 790.82,
    "fmm": 790.82,
    "totalSalary": 790.82,
    "sourceRow": 42
  },
  {
    "id": "departamenti-tehniki-44",
    "parentId": "general-director",
    "type": "department",
    "nameTj": "Департаменти техникӣ",
    "nameRu": "Технический департамент",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ"
    ],
    "headcount": 32.0,
    "positionCount": 23,
    "salary": 120400.0,
    "fmm": 120400.0,
    "totalSalary": 88320.0,
    "sourceRow": 44
  },
  {
    "id": "position-direktori-tehniki-45",
    "parentId": "departamenti-tehniki-44",
    "type": "position",
    "nameTj": "Директори техникӣ",
    "nameRu": "Технический директор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Директори техникӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 8100.0,
    "fmm": 8100.0,
    "totalSalary": 8100.0,
    "sourceRow": 45
  },
  {
    "id": "position-ronanda-46",
    "parentId": "departamenti-tehniki-44",
    "type": "position",
    "nameTj": "Ронанда",
    "nameRu": "Водитель",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Ронанда"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2300.0,
    "fmm": 2300.0,
    "totalSalary": 2300.0,
    "sourceRow": 46
  },
  {
    "id": "shubai-idorakunii-shabaka-va-nazorati-sifat-47",
    "parentId": "departamenti-tehniki-44",
    "type": "division",
    "nameTj": "Шуъбаи идоракунии шабака ва назорати сифат",
    "nameRu": "Отдел управления сетью и контроля качества",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Шуъбаи идоракунии шабака ва назорати сифат"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 47
  },
  {
    "id": "position-sardori-shuba-48",
    "parentId": "shubai-idorakunii-shabaka-va-nazorati-sifat-47",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Шуъбаи идоракунии шабака ва назорати сифат",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 48
  },
  {
    "id": "bahshi-idorakunii-shabaka-49",
    "parentId": "departamenti-tehniki-44",
    "type": "section",
    "nameTj": "Бахши идоракунии шабака",
    "nameRu": "Сектор управления сетью",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши идоракунии шабака"
    ],
    "headcount": 3.0,
    "positionCount": 2,
    "salary": 11500.0,
    "fmm": 11500.0,
    "totalSalary": 6920.0,
    "sourceRow": 49
  },
  {
    "id": "position-sardori-bahsh-50",
    "parentId": "bahshi-idorakunii-shabaka-49",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши идоракунии шабака",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 50
  },
  {
    "id": "position-muhandisi-idorakunii-shabaka-51",
    "parentId": "bahshi-idorakunii-shabaka-49",
    "type": "position",
    "nameTj": "Муҳандиси идоракунии шабака",
    "nameRu": "Инженер по управлению сетью",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши идоракунии шабака",
      "Муҳандиси идоракунии шабака"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 7000.0,
    "totalSalary": 2300.0,
    "sourceRow": 51
  },
  {
    "id": "bahshi-nazorati-sifati-shabaka-52",
    "parentId": "departamenti-tehniki-44",
    "type": "section",
    "nameTj": "Бахши назорати сифати шабака",
    "nameRu": "Сектор контроля качества сети",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши назорати сифати шабака"
    ],
    "headcount": 2.0,
    "positionCount": 2,
    "salary": 7500.0,
    "fmm": 7500.0,
    "totalSalary": 4020.0,
    "sourceRow": 52
  },
  {
    "id": "position-sardori-bahsh-53",
    "parentId": "bahshi-nazorati-sifati-shabaka-52",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши назорати сифати шабака",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 2300.0,
    "sourceRow": 53
  },
  {
    "id": "position-mutahassis-oid-ba-nazorati-sifati-shabaka-54",
    "parentId": "bahshi-nazorati-sifati-shabaka-52",
    "type": "position",
    "nameTj": "Мутахассис оид ба назорати сифати шабака",
    "nameRu": "Специалист по контролю качества сети",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши назорати сифати шабака",
      "Мутахассис оид ба назорати сифати шабака"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 1720.0,
    "sourceRow": 54
  },
  {
    "id": "shubai-banaqshagiri-va-rushdi-shabaka-55",
    "parentId": "departamenti-tehniki-44",
    "type": "division",
    "nameTj": "Шуъбаи банақшагирӣ ва рушди шабака",
    "nameRu": "Отдел планирования и развития сети",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Шуъбаи банақшагирӣ ва рушди шабака"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 55
  },
  {
    "id": "position-sardori-shuba-56",
    "parentId": "shubai-banaqshagiri-va-rushdi-shabaka-55",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Шуъбаи банақшагирӣ ва рушди шабака",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 56
  },
  {
    "id": "bahshi-banaqshagiri-57",
    "parentId": "departamenti-tehniki-44",
    "type": "section",
    "nameTj": "Бахши банақшагирӣ",
    "nameRu": "Сектор планирования",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши банақшагирӣ"
    ],
    "headcount": 2.0,
    "positionCount": 2,
    "salary": 8000.0,
    "fmm": 8000.0,
    "totalSalary": 6960.0,
    "sourceRow": 57
  },
  {
    "id": "position-sardori-bahsh-58",
    "parentId": "bahshi-banaqshagiri-57",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши банақшагирӣ",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 3460.0,
    "sourceRow": 58
  },
  {
    "id": "position-muhandis-oid-ba-banaqshagiri-59",
    "parentId": "bahshi-banaqshagiri-57",
    "type": "position",
    "nameTj": "Муҳандис оид ба банақшагирӣ",
    "nameRu": "Инженер по планированию",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши банақшагирӣ",
      "Муҳандис оид ба банақшагирӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3500.0,
    "sourceRow": 59
  },
  {
    "id": "bahshi-rushdi-shabaka-60",
    "parentId": "departamenti-tehniki-44",
    "type": "section",
    "nameTj": "Бахши рушди шабака",
    "nameRu": "Сектор развития сети",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши рушди шабака"
    ],
    "headcount": 3.0,
    "positionCount": 3,
    "salary": 11000.0,
    "fmm": 11000.0,
    "totalSalary": 9220.0,
    "sourceRow": 60
  },
  {
    "id": "position-sardori-bahsh-61",
    "parentId": "bahshi-rushdi-shabaka-60",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши рушди шабака",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 3460.0,
    "sourceRow": 61
  },
  {
    "id": "position-muhandis-oid-ba-rushdi-shabaka-62",
    "parentId": "bahshi-rushdi-shabaka-60",
    "type": "position",
    "nameTj": "Муҳандис оид ба рушди шабака",
    "nameRu": "Инженер по развитию сети",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши рушди шабака",
      "Муҳандис оид ба рушди шабака"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 2300.0,
    "sourceRow": 62
  },
  {
    "id": "position-mutahassisi-hujjatguzorii-istehsoli-tehniki-63",
    "parentId": "bahshi-rushdi-shabaka-60",
    "type": "position",
    "nameTj": "Мутахассиси ҳуҷҷатгузории истеҳсолӣ-техникӣ",
    "nameRu": "Специалист по производственно-технической документации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши рушди шабака",
      "Мутахассиси ҳуҷҷатгузории истеҳсолӣ-техникӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3460.0,
    "sourceRow": 63
  },
  {
    "id": "shubai-istifodabarii-shabaka-64",
    "parentId": "departamenti-tehniki-44",
    "type": "division",
    "nameTj": "Шуъбаи истифодабарии шабака",
    "nameRu": "Отдел эксплуатации сети",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Шуъбаи истифодабарии шабака"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 64
  },
  {
    "id": "position-sardori-shuba-65",
    "parentId": "shubai-istifodabarii-shabaka-64",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Шуъбаи истифодабарии шабака",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 65
  },
  {
    "id": "bahshi-istifodabarii-hathoi-aloqa-66",
    "parentId": "departamenti-tehniki-44",
    "type": "section",
    "nameTj": "Бахши истифодабарии хатҳои алоқа",
    "nameRu": "Сектор эксплуатации линий связи",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши истифодабарии хатҳои алоқа"
    ],
    "headcount": 4.0,
    "positionCount": 3,
    "salary": 14000.0,
    "fmm": 14000.0,
    "totalSalary": 10380.0,
    "sourceRow": 66
  },
  {
    "id": "position-sardori-bahsh-67",
    "parentId": "bahshi-istifodabarii-hathoi-aloqa-66",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши истифодабарии хатҳои алоқа",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 67
  },
  {
    "id": "position-muhandis-68",
    "parentId": "bahshi-istifodabarii-hathoi-aloqa-66",
    "type": "position",
    "nameTj": "Муҳандис",
    "nameRu": "Инженер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши истифодабарии хатҳои алоқа",
      "Муҳандис"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 2300.0,
    "sourceRow": 68
  },
  {
    "id": "position-mutahassis-69",
    "parentId": "bahshi-istifodabarii-hathoi-aloqa-66",
    "type": "position",
    "nameTj": "Мутахассис",
    "nameRu": "Специалист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши истифодабарии хатҳои алоқа",
      "Мутахассис"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3460.0,
    "sourceRow": 69
  },
  {
    "id": "bahshi-kor-bo-mushtarien-70",
    "parentId": "departamenti-tehniki-44",
    "type": "section",
    "nameTj": "Бахши кор бо муштариён",
    "nameRu": "Сектор по работе с абонентами",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши кор бо муштариён"
    ],
    "headcount": 11.0,
    "positionCount": 4,
    "salary": 36000.0,
    "fmm": 36000.0,
    "totalSalary": 16160.0,
    "sourceRow": 70
  },
  {
    "id": "position-sardori-bahsh-71",
    "parentId": "bahshi-kor-bo-mushtarien-70",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши кор бо муштариён",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 5780.0,
    "sourceRow": 71
  },
  {
    "id": "position-muhandis-72",
    "parentId": "bahshi-kor-bo-mushtarien-70",
    "type": "position",
    "nameTj": "Муҳандис",
    "nameRu": "Инженер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши кор бо муштариён",
      "Муҳандис"
    ],
    "headcount": 3.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 10500.0,
    "totalSalary": 3460.0,
    "sourceRow": 72
  },
  {
    "id": "position-mutahassis-73",
    "parentId": "bahshi-kor-bo-mushtarien-70",
    "type": "position",
    "nameTj": "Мутахассис",
    "nameRu": "Специалист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши кор бо муштариён",
      "Мутахассис"
    ],
    "headcount": 5.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 15000.0,
    "totalSalary": 3460.0,
    "sourceRow": 73
  },
  {
    "id": "position-mutahassis-oid-ba-hizmatrasonii-sadamavi-74",
    "parentId": "bahshi-kor-bo-mushtarien-70",
    "type": "position",
    "nameTj": "Мутахассис оид ба хизматрасонии садамавӣ",
    "nameRu": "Специалист по аварийному обслуживанию",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши кор бо муштариён",
      "Мутахассис оид ба хизматрасонии садамавӣ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3460.0,
    "sourceRow": 74
  },
  {
    "id": "bahshi-taminoti-barq-75",
    "parentId": "departamenti-tehniki-44",
    "type": "section",
    "nameTj": "Бахши таъминоти барқ",
    "nameRu": "Сектор электроснабжения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши таъминоти барқ"
    ],
    "headcount": 2.0,
    "positionCount": 2,
    "salary": 7000.0,
    "fmm": 7000.0,
    "totalSalary": 6920.0,
    "sourceRow": 75
  },
  {
    "id": "position-muhandis-energetik-76",
    "parentId": "bahshi-taminoti-barq-75",
    "type": "position",
    "nameTj": "Муҳандис-энергетик",
    "nameRu": "Инженер-энергетик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши таъминоти барқ",
      "Муҳандис-энергетик"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3460.0,
    "sourceRow": 76
  },
  {
    "id": "position-muhandis-77",
    "parentId": "bahshi-taminoti-barq-75",
    "type": "position",
    "nameTj": "Муҳандис",
    "nameRu": "Инженер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти техникӣ",
      "Бахши таъминоти барқ",
      "Муҳандис"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3460.0,
    "sourceRow": 77
  },
  {
    "id": "departamenti-idorakunii-loihahoi-strategi-79",
    "parentId": "general-director",
    "type": "department",
    "nameTj": "Департаменти идоракунии лоиҳаҳои стратегӣ",
    "nameRu": "Департамент управления стратегическими проектами",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ"
    ],
    "headcount": 190.0,
    "positionCount": 101,
    "salary": 581200.0,
    "fmm": 581320.0,
    "totalSalary": 342220.0,
    "sourceRow": 79
  },
  {
    "id": "position-direktor-oid-ba-idorakunii-loihahoi-strategi-80",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "position",
    "nameTj": "Директор оид ба идоракунии лоиҳаҳои стратегӣ",
    "nameRu": "Директор по управлению стратегическими проектами",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Директор оид ба идоракунии лоиҳаҳои стратегӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 8100.0,
    "fmm": 8100.0,
    "totalSalary": 8100.0,
    "sourceRow": 80
  },
  {
    "id": "position-evari-direktor-oid-ba-idorakunii-loihahoi-strategi-81",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "position",
    "nameTj": "Ёвари директор оид ба идоракунии лоиҳаҳои стратегӣ",
    "nameRu": "Помощник директора по управлению стратегическими проектами",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Ёвари директор оид ба идоракунии лоиҳаҳои стратегӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3000.0,
    "sourceRow": 81
  },
  {
    "id": "position-huquqshinos-82",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "position",
    "nameTj": "Ҳуқуқшинос",
    "nameRu": "Юрист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Ҳуқуқшинос"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 4000.0,
    "sourceRow": 82
  },
  {
    "id": "loihai-tashkili-tavaqqufgohhoi-muzdnok-nuqtahoi-barqdihanda-va-n",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "project",
    "nameTj": "Лоиҳаи «Ташкили таваққуфгоҳҳои музднок, нуқтаҳои барқдиҳанда ва низоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ дар Ҷумҳурии Тоҷикистон» - NERU",
    "nameRu": "Проект \"Организация платных парковок, зарядных станций и автоматизированной системы регистрации нарушений правил дорожного движения в Республике Таджикистан\" - NERU",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Ташкили таваққуфгоҳҳои музднок, нуқтаҳои барқдиҳанда ва низоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ дар Ҷумҳурии Тоҷикистон» - NERU"
    ],
    "headcount": 0,
    "positionCount": 0,
    "salary": 0,
    "fmm": 0,
    "totalSalary": 0,
    "sourceRow": 83
  },
  {
    "id": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "subsystem",
    "nameTj": "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
    "nameRu": "Подсистема автоматизированной фиксации нарушений правил дорожного движения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ"
    ],
    "headcount": 22.0,
    "positionCount": 14,
    "salary": 71600.0,
    "fmm": 71720.0,
    "totalSalary": 46680.0,
    "sourceRow": 84
  },
  {
    "id": "position-menejer-85",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Менеҷер",
    "nameRu": "Менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Менеҷер"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6100.0,
    "fmm": 6100.0,
    "totalSalary": 3000.0,
    "sourceRow": 85
  },
  {
    "id": "position-menejeri-mintaqavi-dar-shahru-nohiyahoi-tobei-jumhuri-8",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Менеҷери минтақавӣ дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
    "nameRu": "Региональный менеджер в городах и районах республиканского подчинения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Менеҷери минтақавӣ дар шаҳру ноҳияҳои тобеи ҷумҳурӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4620.0,
    "totalSalary": 4620.0,
    "sourceRow": 86
  },
  {
    "id": "position-menejeri-mintaqavi-dar-viloyati-sugd-87",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Менеҷери минтақавӣ дар вилояти Суғд",
    "nameRu": "Региональный менеджер в Согдийской области",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Менеҷери минтақавӣ дар вилояти Суғд"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 87
  },
  {
    "id": "position-menejeri-mintaqavi-dar-viloyati-hatlon-88",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Менеҷери минтақавӣ дар вилояти Хатлон",
    "nameRu": "Региональный менеджер в Хатлонской области",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Менеҷери минтақавӣ дар вилояти Хатлон"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 88
  },
  {
    "id": "position-menejer-oid-ba-kor-bo-maqomothoi-davlati-89",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Менеҷер оид ба кор бо мақомотҳои давлатӣ",
    "nameRu": "Менеджер по работе с государственными органами",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Менеҷер оид ба кор бо мақомотҳои давлатӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 3500.0,
    "sourceRow": 89
  },
  {
    "id": "position-menejer-oid-ba-nazorati-kamerahoi-tartiboti-jamiyati-90",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Менеҷер оид ба назорати камераҳои тартиботи ҷамъиятӣ",
    "nameRu": "Менеджер по контролю камер общественного порядка",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Менеҷер оид ба назорати камераҳои тартиботи ҷамъиятӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 4620.0,
    "sourceRow": 90
  },
  {
    "id": "position-sarmutahassis-oid-ba-hamohangsozii-loiha-91",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Сармутахассис оид ба ҳамоҳангсозии лоиҳа",
    "nameRu": "Главный специалист по проектной координации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Сармутахассис оид ба ҳамоҳангсозии лоиҳа"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3500.0,
    "sourceRow": 91
  },
  {
    "id": "position-mutahassis-oid-ba-hamohangsozii-loiha-92",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Мутахассис оид ба ҳамоҳангсозии лоиҳа",
    "nameRu": "Специалист по проектной координации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Мутахассис оид ба ҳамоҳангсозии лоиҳа"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 92
  },
  {
    "id": "position-mutahassis-oid-ba-monitoring-va-audit-93",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Мутахассис оид ба мониторинг ва аудит",
    "nameRu": "Специалист по мониторингу и аудиту",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Мутахассис оид ба мониторинг ва аудит"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 93
  },
  {
    "id": "position-sarmoderatori-vayronkunii-qoidahoi-harakat-dar-roh-94",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Сармодератори вайронкунии қоидаҳои ҳаракат дар роҳ",
    "nameRu": "Главный модератор нарушений правил дорожного движения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Сармодератори вайронкунии қоидаҳои ҳаракат дар роҳ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3500.0,
    "sourceRow": 94
  },
  {
    "id": "position-moderatori-kaloni-vayronkunii-qoidahoi-harakat-dar-roh-",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Модератори калони вайронкунии қоидаҳои ҳаракат дар роҳ",
    "nameRu": "Старший модератор нарушений правил дорожного движения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Модератори калони вайронкунии қоидаҳои ҳаракат дар роҳ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 2500.0,
    "sourceRow": 95
  },
  {
    "id": "position-dispetcheri-nizomi-monitoring-96",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Диспетчери низоми мониторинг",
    "nameRu": "Диспетчер мониторинга системы",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Диспетчери низоми мониторинг"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 2500.0,
    "totalSalary": 1700.0,
    "sourceRow": 96
  },
  {
    "id": "position-moderatori-vayronkunii-qoidahoi-harakat-dar-roh-97",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Модератори вайронкунии қоидаҳои ҳаракат дар роҳ",
    "nameRu": "Модератор нарушений правил дорожного движения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Модератори вайронкунии қоидаҳои ҳаракат дар роҳ"
    ],
    "headcount": 7.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 17500.0,
    "totalSalary": 2500.0,
    "sourceRow": 97
  },
  {
    "id": "position-barnomasoz-98",
    "parentId": "zernizomi-avtomatikunonidashudai-baqaydgirii-vayronkunii-qoidaho",
    "type": "position",
    "nameTj": "Барномасоз",
    "nameRu": "Программист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми автоматикунонидашудаи бақайдгирии вайронкунии қоидаҳои ҳаракат дар роҳ",
      "Барномасоз"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2000.0,
    "fmm": 2000.0,
    "totalSalary": 2000.0,
    "sourceRow": 98
  },
  {
    "id": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "subsystem",
    "nameTj": "Зернизоми таваққуфгоҳҳои музднок",
    "nameRu": "Подсистема платных парковок",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок"
    ],
    "headcount": 12.0,
    "positionCount": 10,
    "salary": 41600.0,
    "fmm": 41600.0,
    "totalSalary": 37300.0,
    "sourceRow": 99
  },
  {
    "id": "position-menejer-100",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Менеҷер",
    "nameRu": "Менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Менеҷер"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6100.0,
    "fmm": 6100.0,
    "totalSalary": 6940.0,
    "sourceRow": 100
  },
  {
    "id": "position-menejeri-mintaqavi-dar-shahru-nohiyahoi-tobei-jumhuri-1",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Менеҷери минтақавӣ дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
    "nameRu": "Региональный менеджер в городах и районах республиканского подчинения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Менеҷери минтақавӣ дар шаҳру ноҳияҳои тобеи ҷумҳурӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 101
  },
  {
    "id": "position-menejeri-mintaqavi-dar-viloyati-sugd-102",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Менеҷери минтақавӣ дар вилояти Суғд",
    "nameRu": "Региональный менеджер в Согдийской области",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Менеҷери минтақавӣ дар вилояти Суғд"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 102
  },
  {
    "id": "position-menejeri-mintaqavi-dar-viloyati-hatlon-103",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Менеҷери минтақавӣ дар вилояти Хатлон",
    "nameRu": "Региональный менеджер в Хатлонской области",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Менеҷери минтақавӣ дар вилояти Хатлон"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 103
  },
  {
    "id": "position-mushovir-oid-ba-kor-bo-maqomothoi-davlati-104",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Мушовир оид ба кор бо мақомотҳои давлатӣ",
    "nameRu": "Консультант по работе с государственными органами",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Мушовир оид ба кор бо мақомотҳои давлатӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 2500.0,
    "totalSalary": 2500.0,
    "sourceRow": 104
  },
  {
    "id": "position-sarmutahassis-oid-ba-hamohangsozii-loiha-105",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Сармутахассис оид ба ҳамоҳангсозии лоиҳа",
    "nameRu": "Главный специалист по проектной координации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Сармутахассис оид ба ҳамоҳангсозии лоиҳа"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3500.0,
    "sourceRow": 105
  },
  {
    "id": "position-mutahassis-oid-ba-hamohangsozii-loiha-106",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Мутахассис оид ба ҳамоҳангсозии лоиҳа",
    "nameRu": "Специалист по проектной координации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Мутахассис оид ба ҳамоҳангсозии лоиҳа"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 106
  },
  {
    "id": "position-mutahassis-oid-ba-monitoring-va-audit-107",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Мутахассис оид ба мониторинг ва аудит",
    "nameRu": "Специалист по мониторингу и аудиту",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Мутахассис оид ба мониторинг ва аудит"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3000.0,
    "sourceRow": 107
  },
  {
    "id": "position-noziri-tavaqqufgoh-108",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Нозири таваққуфгоҳ",
    "nameRu": "Инспектор парковки",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Нозири таваққуфгоҳ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 5000.0,
    "totalSalary": 2500.0,
    "sourceRow": 108
  },
  {
    "id": "position-barnomasoz-109",
    "parentId": "zernizomi-tavaqqufgohhoi-muzdnok-99",
    "type": "position",
    "nameTj": "Барномасоз",
    "nameRu": "Программист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳҳои музднок",
      "Барномасоз"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2000.0,
    "fmm": 2000.0,
    "totalSalary": 2000.0,
    "sourceRow": 109
  },
  {
    "id": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "subsystem",
    "nameTj": "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
    "nameRu": "Подсистема зарядных станций для электрических транспортных средств",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ"
    ],
    "headcount": 10.0,
    "positionCount": 9,
    "salary": 36600.0,
    "fmm": 36600.0,
    "totalSalary": 34800.0,
    "sourceRow": 110
  },
  {
    "id": "position-menejer-111",
    "parentId": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "type": "position",
    "nameTj": "Менеҷер",
    "nameRu": "Менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
      "Менеҷер"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6100.0,
    "fmm": 6100.0,
    "totalSalary": 6940.0,
    "sourceRow": 111
  },
  {
    "id": "position-menejeri-mintaqavi-dar-shahru-nohiyahoi-tobei-jumhuri-1-2",
    "parentId": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "type": "position",
    "nameTj": "Менеҷери минтақавӣ дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
    "nameRu": "Региональный менеджер в городах и районах республиканского подчинения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
      "Менеҷери минтақавӣ дар шаҳру ноҳияҳои тобеи ҷумҳурӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 112
  },
  {
    "id": "position-menejeri-mintaqavi-dar-viloyati-hatlon-113",
    "parentId": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "type": "position",
    "nameTj": "Менеҷери минтақавӣ дар вилояти Хатлон",
    "nameRu": "Региональный менеджер в Хатлонской области",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
      "Менеҷери минтақавӣ дар вилояти Хатлон"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 113
  },
  {
    "id": "position-menejeri-mintaqavi-dar-viloyati-sugd-114",
    "parentId": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "type": "position",
    "nameTj": "Менеҷери минтақавӣ дар вилояти Суғд",
    "nameRu": "Региональный менеджер в Согдийской области",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
      "Менеҷери минтақавӣ дар вилояти Суғд"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 114
  },
  {
    "id": "position-mushovir-oid-ba-kor-bo-maqomothoi-davlati-115",
    "parentId": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "type": "position",
    "nameTj": "Мушовир оид ба кор бо мақомотҳои давлатӣ",
    "nameRu": "Консультант по работе с государственными органами",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
      "Мушовир оид ба кор бо мақомотҳои давлатӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 2500.0,
    "totalSalary": 2500.0,
    "sourceRow": 115
  },
  {
    "id": "position-sarmutahassis-oid-ba-hamohangsozii-loiha-116",
    "parentId": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "type": "position",
    "nameTj": "Сармутахассис оид ба ҳамоҳангсозии лоиҳа",
    "nameRu": "Главный специалист по проектной координации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
      "Сармутахассис оид ба ҳамоҳангсозии лоиҳа"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3500.0,
    "sourceRow": 116
  },
  {
    "id": "position-mutahassis-oid-ba-hamohangsozii-loiha-117",
    "parentId": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "type": "position",
    "nameTj": "Мутахассис оид ба ҳамоҳангсозии лоиҳа",
    "nameRu": "Специалист по проектной координации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
      "Мутахассис оид ба ҳамоҳангсозии лоиҳа"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 117
  },
  {
    "id": "position-mutahassis-oid-ba-monitoring-va-audit-118",
    "parentId": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "type": "position",
    "nameTj": "Мутахассис оид ба мониторинг ва аудит",
    "nameRu": "Специалист по мониторингу и аудиту",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
      "Мутахассис оид ба мониторинг ва аудит"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3000.0,
    "sourceRow": 118
  },
  {
    "id": "position-barnomasoz-119",
    "parentId": "zernizomi-nuqtahoi-barqdihanda-baroi-vositahoi-naqlieti-barqi-11",
    "type": "position",
    "nameTj": "Барномасоз",
    "nameRu": "Программист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми нуқтаҳои барқдиҳанда барои воситаҳои нақлиёти барқӣ",
      "Барномасоз"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2000.0,
    "fmm": 2000.0,
    "totalSalary": 2000.0,
    "sourceRow": 119
  },
  {
    "id": "zernizomi-tavaqqufgohi-jarimavi-120",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "subsystem",
    "nameTj": "Зернизоми таваққуфгоҳи ҷаримавӣ",
    "nameRu": "Подсистема Штрафплощадки",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳи ҷаримавӣ"
    ],
    "headcount": 4.0,
    "positionCount": 4,
    "salary": 15600.0,
    "fmm": 15600.0,
    "totalSalary": 14940.0,
    "sourceRow": 120
  },
  {
    "id": "position-menejer-121",
    "parentId": "zernizomi-tavaqqufgohi-jarimavi-120",
    "type": "position",
    "nameTj": "Менеҷер",
    "nameRu": "Менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳи ҷаримавӣ",
      "Менеҷер"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6100.0,
    "fmm": 6100.0,
    "totalSalary": 6940.0,
    "sourceRow": 121
  },
  {
    "id": "position-sardori-tavaqqufgohi-jarimavi-122",
    "parentId": "zernizomi-tavaqqufgohi-jarimavi-120",
    "type": "position",
    "nameTj": "Сардори таваққуфгоҳи ҷаримавӣ",
    "nameRu": "Начальник штрафплощадки",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳи ҷаримавӣ",
      "Сардори таваққуфгоҳи ҷаримавӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 3500.0,
    "sourceRow": 122
  },
  {
    "id": "position-mushovir-oid-ba-kor-bo-nozironi-bda-sh-dushanbe-123",
    "parentId": "zernizomi-tavaqqufgohi-jarimavi-120",
    "type": "position",
    "nameTj": "Мушовир оид ба кор бо нозирони БДА ш. Душанбе",
    "nameRu": "Консультант по работе с инспекторами ГАИ г. Душанбе",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳи ҷаримавӣ",
      "Мушовир оид ба кор бо нозирони БДА ш. Душанбе"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 2500.0,
    "totalSalary": 2500.0,
    "sourceRow": 123
  },
  {
    "id": "position-barnomasoz-124",
    "parentId": "zernizomi-tavaqqufgohi-jarimavi-120",
    "type": "position",
    "nameTj": "Барномасоз",
    "nameRu": "Программист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми таваққуфгоҳи ҷаримавӣ",
      "Барномасоз"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2000.0,
    "fmm": 2000.0,
    "totalSalary": 2000.0,
    "sourceRow": 124
  },
  {
    "id": "zernizomi-baqaydgiri-va-barasmiyatdarorii-vositahoi-naqliet-125",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "subsystem",
    "nameTj": "Зернизоми бақайдгирӣ ва барасмиятдарории воситаҳои нақлиёт",
    "nameRu": "Подсистема регистрации и таможенного оформления транспортных средств",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми бақайдгирӣ ва барасмиятдарории воситаҳои нақлиёт"
    ],
    "headcount": 6.0,
    "positionCount": 4,
    "salary": 22100.0,
    "fmm": 22100.0,
    "totalSalary": 16560.0,
    "sourceRow": 125
  },
  {
    "id": "position-menejer-126",
    "parentId": "zernizomi-baqaydgiri-va-barasmiyatdarorii-vositahoi-naqliet-125",
    "type": "position",
    "nameTj": "Менеҷер",
    "nameRu": "Менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми бақайдгирӣ ва барасмиятдарории воситаҳои нақлиёт",
      "Менеҷер"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6100.0,
    "fmm": 6100.0,
    "totalSalary": 6940.0,
    "sourceRow": 126
  },
  {
    "id": "position-mutahassis-oid-ba-monitoring-va-audit-127",
    "parentId": "zernizomi-baqaydgiri-va-barasmiyatdarorii-vositahoi-naqliet-125",
    "type": "position",
    "nameTj": "Мутахассис оид ба мониторинг ва аудит",
    "nameRu": "Специалист по мониторингу и аудиту",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми бақайдгирӣ ва барасмиятдарории воситаҳои нақлиёт",
      "Мутахассис оид ба мониторинг ва аудит"
    ],
    "headcount": 3.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 9000.0,
    "totalSalary": 3000.0,
    "sourceRow": 127
  },
  {
    "id": "position-barnomasoz-128",
    "parentId": "zernizomi-baqaydgiri-va-barasmiyatdarorii-vositahoi-naqliet-125",
    "type": "position",
    "nameTj": "Барномасоз",
    "nameRu": "Программист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми бақайдгирӣ ва барасмиятдарории воситаҳои нақлиёт",
      "Барномасоз"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2000.0,
    "fmm": 2000.0,
    "totalSalary": 2000.0,
    "sourceRow": 128
  },
  {
    "id": "shubai-hizmatrasonii-tehniki-va-taminoti-barnomavi-129",
    "parentId": "zernizomi-baqaydgiri-va-barasmiyatdarorii-vositahoi-naqliet-125",
    "type": "division",
    "nameTj": "Шуъбаи хизматрасонии техникӣ ва таъминоти барномавӣ",
    "nameRu": "Отдел технического обслуживания и программного сопровождения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми бақайдгирӣ ва барасмиятдарории воситаҳои нақлиёт",
      "Шуъбаи хизматрасонии техникӣ ва таъминоти барномавӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 4620.0,
    "sourceRow": 129
  },
  {
    "id": "position-sardori-shuba-130",
    "parentId": "shubai-hizmatrasonii-tehniki-va-taminoti-barnomavi-129",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Зернизоми бақайдгирӣ ва барасмиятдарории воситаҳои нақлиёт",
      "Шуъбаи хизматрасонии техникӣ ва таъминоти барномавӣ",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 4620.0,
    "sourceRow": 130
  },
  {
    "id": "bahsh-dar-shahri-dushanbe-131",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "section",
    "nameTj": "Бахш дар шаҳри Душанбе",
    "nameRu": "Сектор в городе Душанбе",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе"
    ],
    "headcount": 50.0,
    "positionCount": 9,
    "salary": 130500.0,
    "fmm": 130500.0,
    "totalSalary": 25000.0,
    "sourceRow": 131
  },
  {
    "id": "position-sardori-bahsh-132",
    "parentId": "bahsh-dar-shahri-dushanbe-131",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4000.0,
    "sourceRow": 132
  },
  {
    "id": "position-tehniki-kalon-133",
    "parentId": "bahsh-dar-shahri-dushanbe-131",
    "type": "position",
    "nameTj": "Техники калон",
    "nameRu": "Старший техник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе",
      "Техники калон"
    ],
    "headcount": 4.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 14000.0,
    "totalSalary": 3500.0,
    "sourceRow": 133
  },
  {
    "id": "position-tehniki-darajai-1-134",
    "parentId": "bahsh-dar-shahri-dushanbe-131",
    "type": "position",
    "nameTj": "Техники дараҷаи 1",
    "nameRu": "Техник 1 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе",
      "Техники дараҷаи 1"
    ],
    "headcount": 8.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 24000.0,
    "totalSalary": 3000.0,
    "sourceRow": 134
  },
  {
    "id": "position-tehniki-darajai-2-135",
    "parentId": "bahsh-dar-shahri-dushanbe-131",
    "type": "position",
    "nameTj": "Техники дараҷаи 2",
    "nameRu": "Техник 2 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе",
      "Техники дараҷаи 2"
    ],
    "headcount": 20.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 50000.0,
    "totalSalary": 2500.0,
    "sourceRow": 135
  },
  {
    "id": "position-barqchii-kalon-136",
    "parentId": "bahsh-dar-shahri-dushanbe-131",
    "type": "position",
    "nameTj": "Барқчии калон",
    "nameRu": "Старший электрик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе",
      "Барқчии калон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 7000.0,
    "totalSalary": 3500.0,
    "sourceRow": 136
  },
  {
    "id": "position-barqchii-darajai-1-137",
    "parentId": "bahsh-dar-shahri-dushanbe-131",
    "type": "position",
    "nameTj": "Барқчии дараҷаи 1",
    "nameRu": "Электрик 1 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе",
      "Барқчии дараҷаи 1"
    ],
    "headcount": 3.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 9000.0,
    "totalSalary": 3000.0,
    "sourceRow": 137
  },
  {
    "id": "position-barqchii-darajai-2-138",
    "parentId": "bahsh-dar-shahri-dushanbe-131",
    "type": "position",
    "nameTj": "Барқчии дараҷаи 2",
    "nameRu": "Электрик 2 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе",
      "Барқчии дараҷаи 2"
    ],
    "headcount": 4.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 10000.0,
    "totalSalary": 2500.0,
    "sourceRow": 138
  },
  {
    "id": "position-tehnik-tamirgar-139",
    "parentId": "bahsh-dar-shahri-dushanbe-131",
    "type": "position",
    "nameTj": "Техник-таъмиргар",
    "nameRu": "Техник-ремонтник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе",
      "Техник-таъмиргар"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 1500.0,
    "fmm": 3000.0,
    "totalSalary": 1500.0,
    "sourceRow": 139
  },
  {
    "id": "position-kormandi-hizmatrason-140",
    "parentId": "bahsh-dar-shahri-dushanbe-131",
    "type": "position",
    "nameTj": "Корманди хизматрасон",
    "nameRu": "Сервисный работник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳри Душанбе",
      "Корманди хизматрасон"
    ],
    "headcount": 6.0,
    "positionCount": 1,
    "salary": 1500.0,
    "fmm": 9000.0,
    "totalSalary": 1500.0,
    "sourceRow": 140
  },
  {
    "id": "bahsh-dar-shahru-nohiyahoi-tobei-jumhuri-141",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "section",
    "nameTj": "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
    "nameRu": "Сектор в городах районах республиканского подчинения",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ"
    ],
    "headcount": 15.0,
    "positionCount": 8,
    "salary": 43500.0,
    "fmm": 43500.0,
    "totalSalary": 23500.0,
    "sourceRow": 141
  },
  {
    "id": "position-sardori-bahsh-142",
    "parentId": "bahsh-dar-shahru-nohiyahoi-tobei-jumhuri-141",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4000.0,
    "sourceRow": 142
  },
  {
    "id": "position-tehniki-kalon-143",
    "parentId": "bahsh-dar-shahru-nohiyahoi-tobei-jumhuri-141",
    "type": "position",
    "nameTj": "Техники калон",
    "nameRu": "Старший техник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
      "Техники калон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 7000.0,
    "totalSalary": 3500.0,
    "sourceRow": 143
  },
  {
    "id": "position-tehniki-darajai-1-144",
    "parentId": "bahsh-dar-shahru-nohiyahoi-tobei-jumhuri-141",
    "type": "position",
    "nameTj": "Техники дараҷаи 1",
    "nameRu": "Техник 1 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
      "Техники дараҷаи 1"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 144
  },
  {
    "id": "position-tehniki-darajai-2-145",
    "parentId": "bahsh-dar-shahru-nohiyahoi-tobei-jumhuri-141",
    "type": "position",
    "nameTj": "Техники дараҷаи 2",
    "nameRu": "Техник 2 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
      "Техники дараҷаи 2"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 5000.0,
    "totalSalary": 2500.0,
    "sourceRow": 145
  },
  {
    "id": "position-barqchii-kalon-146",
    "parentId": "bahsh-dar-shahru-nohiyahoi-tobei-jumhuri-141",
    "type": "position",
    "nameTj": "Барқчии калон",
    "nameRu": "Старший электрик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
      "Барқчии калон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 7000.0,
    "totalSalary": 3500.0,
    "sourceRow": 146
  },
  {
    "id": "position-barqchii-darajai-1-147",
    "parentId": "bahsh-dar-shahru-nohiyahoi-tobei-jumhuri-141",
    "type": "position",
    "nameTj": "Барқчии дараҷаи 1",
    "nameRu": "Электрик 1 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
      "Барқчии дараҷаи 1"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 147
  },
  {
    "id": "position-barqchii-darajai-2-148",
    "parentId": "bahsh-dar-shahru-nohiyahoi-tobei-jumhuri-141",
    "type": "position",
    "nameTj": "Барқчии дараҷаи 2",
    "nameRu": "Электрик 2 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
      "Барқчии дараҷаи 2"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 5000.0,
    "totalSalary": 2500.0,
    "sourceRow": 148
  },
  {
    "id": "position-kormandi-hizmatrason-149",
    "parentId": "bahsh-dar-shahru-nohiyahoi-tobei-jumhuri-141",
    "type": "position",
    "nameTj": "Корманди хизматрасон",
    "nameRu": "Сервисный работник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар шаҳру ноҳияҳои тобеи ҷумҳурӣ",
      "Корманди хизматрасон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 1500.0,
    "fmm": 3000.0,
    "totalSalary": 1500.0,
    "sourceRow": 149
  },
  {
    "id": "bahsh-dar-viloyati-hatlon-150",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "section",
    "nameTj": "Бахш дар вилояти Хатлон",
    "nameRu": "Сектор в Хатлонской области",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Хатлон"
    ],
    "headcount": 15.0,
    "positionCount": 8,
    "salary": 43500.0,
    "fmm": 43500.0,
    "totalSalary": 23500.0,
    "sourceRow": 150
  },
  {
    "id": "position-sardori-bahsh-151",
    "parentId": "bahsh-dar-viloyati-hatlon-150",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Хатлон",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4000.0,
    "sourceRow": 151
  },
  {
    "id": "position-tehniki-kalon-152",
    "parentId": "bahsh-dar-viloyati-hatlon-150",
    "type": "position",
    "nameTj": "Техники калон",
    "nameRu": "Старший техник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Хатлон",
      "Техники калон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 7000.0,
    "totalSalary": 3500.0,
    "sourceRow": 152
  },
  {
    "id": "position-tehniki-darajai-1-153",
    "parentId": "bahsh-dar-viloyati-hatlon-150",
    "type": "position",
    "nameTj": "Техники дараҷаи 1",
    "nameRu": "Техник 1 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Хатлон",
      "Техники дараҷаи 1"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 153
  },
  {
    "id": "position-tehniki-darajai-2-154",
    "parentId": "bahsh-dar-viloyati-hatlon-150",
    "type": "position",
    "nameTj": "Техники дараҷаи 2",
    "nameRu": "Техник 2 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Хатлон",
      "Техники дараҷаи 2"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 5000.0,
    "totalSalary": 2500.0,
    "sourceRow": 154
  },
  {
    "id": "position-barqchii-kalon-155",
    "parentId": "bahsh-dar-viloyati-hatlon-150",
    "type": "position",
    "nameTj": "Барқчии калон",
    "nameRu": "Старший электрик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Хатлон",
      "Барқчии калон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 7000.0,
    "totalSalary": 3500.0,
    "sourceRow": 155
  },
  {
    "id": "position-barqchii-darajai-1-156",
    "parentId": "bahsh-dar-viloyati-hatlon-150",
    "type": "position",
    "nameTj": "Барқчии дараҷаи 1",
    "nameRu": "Электрик 1 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Хатлон",
      "Барқчии дараҷаи 1"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 156
  },
  {
    "id": "position-barqchii-darajai-2-157",
    "parentId": "bahsh-dar-viloyati-hatlon-150",
    "type": "position",
    "nameTj": "Барқчии дараҷаи 2",
    "nameRu": "Электрик 2 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Хатлон",
      "Барқчии дараҷаи 2"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 5000.0,
    "totalSalary": 2500.0,
    "sourceRow": 157
  },
  {
    "id": "position-kormandi-hizmatrason-158",
    "parentId": "bahsh-dar-viloyati-hatlon-150",
    "type": "position",
    "nameTj": "Корманди хизматрасон",
    "nameRu": "Сервисный работник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Хатлон",
      "Корманди хизматрасон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 1500.0,
    "fmm": 3000.0,
    "totalSalary": 1500.0,
    "sourceRow": 158
  },
  {
    "id": "bahsh-dar-viloyati-sugd-159",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "section",
    "nameTj": "Бахш дар вилояти Суғд",
    "nameRu": "Сектор в Согдийской области",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Суғд"
    ],
    "headcount": 15.0,
    "positionCount": 8,
    "salary": 43500.0,
    "fmm": 43500.0,
    "totalSalary": 23500.0,
    "sourceRow": 159
  },
  {
    "id": "position-sardori-bahsh-160",
    "parentId": "bahsh-dar-viloyati-sugd-159",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Суғд",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4000.0,
    "sourceRow": 160
  },
  {
    "id": "position-tehniki-kalon-161",
    "parentId": "bahsh-dar-viloyati-sugd-159",
    "type": "position",
    "nameTj": "Техники калон",
    "nameRu": "Старший техник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Суғд",
      "Техники калон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 7000.0,
    "totalSalary": 3500.0,
    "sourceRow": 161
  },
  {
    "id": "position-tehniki-darajai-1-162",
    "parentId": "bahsh-dar-viloyati-sugd-159",
    "type": "position",
    "nameTj": "Техники дараҷаи 1",
    "nameRu": "Техник 1 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Суғд",
      "Техники дараҷаи 1"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 162
  },
  {
    "id": "position-tehniki-darajai-2-163",
    "parentId": "bahsh-dar-viloyati-sugd-159",
    "type": "position",
    "nameTj": "Техники дараҷаи 2",
    "nameRu": "Техник 2 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Суғд",
      "Техники дараҷаи 2"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 5000.0,
    "totalSalary": 2500.0,
    "sourceRow": 163
  },
  {
    "id": "position-barqchii-kalon-164",
    "parentId": "bahsh-dar-viloyati-sugd-159",
    "type": "position",
    "nameTj": "Барқчии калон",
    "nameRu": "Старший электрик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Суғд",
      "Барқчии калон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 7000.0,
    "totalSalary": 3500.0,
    "sourceRow": 164
  },
  {
    "id": "position-barqchii-darajai-1-165",
    "parentId": "bahsh-dar-viloyati-sugd-159",
    "type": "position",
    "nameTj": "Барқчии дараҷаи 1",
    "nameRu": "Электрик 1 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Суғд",
      "Барқчии дараҷаи 1"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 165
  },
  {
    "id": "position-barqchii-darajai-2-166",
    "parentId": "bahsh-dar-viloyati-sugd-159",
    "type": "position",
    "nameTj": "Барқчии дараҷаи 2",
    "nameRu": "Электрик 2 категории",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Суғд",
      "Барқчии дараҷаи 2"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 5000.0,
    "totalSalary": 2500.0,
    "sourceRow": 166
  },
  {
    "id": "position-kormandi-hizmatrason-167",
    "parentId": "bahsh-dar-viloyati-sugd-159",
    "type": "position",
    "nameTj": "Корманди хизматрасон",
    "nameRu": "Сервисный работник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Бахш дар вилояти Суғд",
      "Корманди хизматрасон"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 1500.0,
    "fmm": 3000.0,
    "totalSalary": 1500.0,
    "sourceRow": 167
  },
  {
    "id": "loihai-baqaydgirii-vositahoi-mobilii-aloqai-barqi-dar-sistemai-d",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "project",
    "nameTj": "Лоиҳаи “Бақайдгирии воситаҳои мобилии алоқаи барқӣ дар системаи давлатии муайянсозии воситаҳои мобилии алоқаи барқӣ\" - IMEI",
    "nameRu": "Проект \"Регистрация мобильных средств электрической связи в государственной системе идентификации мобильных средств электрической связи\" - IMEI",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи “Бақайдгирии воситаҳои мобилии алоқаи барқӣ дар системаи давлатии муайянсозии воситаҳои мобилии алоқаи барқӣ\" - IMEI"
    ],
    "headcount": 9.0,
    "positionCount": 6,
    "salary": 29600.0,
    "fmm": 29600.0,
    "totalSalary": 21440.0,
    "sourceRow": 169
  },
  {
    "id": "position-menejer-170",
    "parentId": "loihai-baqaydgirii-vositahoi-mobilii-aloqai-barqi-dar-sistemai-d",
    "type": "position",
    "nameTj": "Менеҷер",
    "nameRu": "Менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи “Бақайдгирии воситаҳои мобилии алоқаи барқӣ дар системаи давлатии муайянсозии воситаҳои мобилии алоқаи барқӣ\" - IMEI",
      "Менеҷер"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6100.0,
    "fmm": 6100.0,
    "totalSalary": 6940.0,
    "sourceRow": 170
  },
  {
    "id": "position-mutahassis-oid-ba-barasmiyatdarorii-gumruki-171",
    "parentId": "loihai-baqaydgirii-vositahoi-mobilii-aloqai-barqi-dar-sistemai-d",
    "type": "position",
    "nameTj": "Мутахассис оид ба барасмиятдарории гумрукӣ",
    "nameRu": "Специалист по таможенному оформлению",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи “Бақайдгирии воситаҳои мобилии алоқаи барқӣ дар системаи давлатии муайянсозии воситаҳои мобилии алоқаи барқӣ\" - IMEI",
      "Мутахассис оид ба барасмиятдарории гумрукӣ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 171
  },
  {
    "id": "position-sarmutahassis-oid-ba-hamohangsozii-loiha-172",
    "parentId": "loihai-baqaydgirii-vositahoi-mobilii-aloqai-barqi-dar-sistemai-d",
    "type": "position",
    "nameTj": "Сармутахассис оид ба ҳамоҳангсозии лоиҳа",
    "nameRu": "Главный специалист по проектной координации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи “Бақайдгирии воситаҳои мобилии алоқаи барқӣ дар системаи давлатии муайянсозии воситаҳои мобилии алоқаи барқӣ\" - IMEI",
      "Сармутахассис оид ба ҳамоҳангсозии лоиҳа"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3500.0,
    "sourceRow": 172
  },
  {
    "id": "position-mutahassis-oid-ba-hamohangsozii-loiha-173",
    "parentId": "loihai-baqaydgirii-vositahoi-mobilii-aloqai-barqi-dar-sistemai-d",
    "type": "position",
    "nameTj": "Мутахассис оид ба ҳамоҳангсозии лоиҳа",
    "nameRu": "Специалист по проектной координации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи “Бақайдгирии воситаҳои мобилии алоқаи барқӣ дар системаи давлатии муайянсозии воситаҳои мобилии алоқаи барқӣ\" - IMEI",
      "Мутахассис оид ба ҳамоҳангсозии лоиҳа"
    ],
    "headcount": 3.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 9000.0,
    "totalSalary": 3000.0,
    "sourceRow": 173
  },
  {
    "id": "position-mutahassis-oid-ba-monitoring-va-audit-174",
    "parentId": "loihai-baqaydgirii-vositahoi-mobilii-aloqai-barqi-dar-sistemai-d",
    "type": "position",
    "nameTj": "Мутахассис оид ба мониторинг ва аудит",
    "nameRu": "Специалист по мониторингу и аудиту",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи “Бақайдгирии воситаҳои мобилии алоқаи барқӣ дар системаи давлатии муайянсозии воситаҳои мобилии алоқаи барқӣ\" - IMEI",
      "Мутахассис оид ба мониторинг ва аудит"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3000.0,
    "sourceRow": 174
  },
  {
    "id": "position-barnomasoz-175",
    "parentId": "loihai-baqaydgirii-vositahoi-mobilii-aloqai-barqi-dar-sistemai-d",
    "type": "position",
    "nameTj": "Барномасоз",
    "nameRu": "Программист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи “Бақайдгирии воситаҳои мобилии алоқаи барқӣ дар системаи давлатии муайянсозии воситаҳои мобилии алоқаи барқӣ\" - IMEI",
      "Барномасоз"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2000.0,
    "fmm": 2000.0,
    "totalSalary": 2000.0,
    "sourceRow": 175
  },
  {
    "id": "loihai-markazi-idorakunii-pardohtho-176",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "project",
    "nameTj": "Лоиҳаи «Маркази идоракунии пардохтҳо»",
    "nameRu": "Проект \"Центр управления платежами\"",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Маркази идоракунии пардохтҳо»"
    ],
    "headcount": 5.0,
    "positionCount": 3,
    "salary": 18100.0,
    "fmm": 18100.0,
    "totalSalary": 12940.0,
    "sourceRow": 176
  },
  {
    "id": "position-menejer-177",
    "parentId": "loihai-markazi-idorakunii-pardohtho-176",
    "type": "position",
    "nameTj": "Менеҷер",
    "nameRu": "Менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Маркази идоракунии пардохтҳо»",
      "Менеҷер"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6100.0,
    "fmm": 6100.0,
    "totalSalary": 6940.0,
    "sourceRow": 177
  },
  {
    "id": "position-mutahassis-oid-ba-hamohangsozii-loiha-178",
    "parentId": "loihai-markazi-idorakunii-pardohtho-176",
    "type": "position",
    "nameTj": "Мутахассис оид ба ҳамоҳангсозии лоиҳа",
    "nameRu": "Специалист по проектной координации",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Маркази идоракунии пардохтҳо»",
      "Мутахассис оид ба ҳамоҳангсозии лоиҳа"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 178
  },
  {
    "id": "position-mutahassis-oid-ba-monitoring-va-audit-179",
    "parentId": "loihai-markazi-idorakunii-pardohtho-176",
    "type": "position",
    "nameTj": "Мутахассис оид ба мониторинг ва аудит",
    "nameRu": "Специалист по мониторингу и аудиту",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Маркази идоракунии пардохтҳо»",
      "Мутахассис оид ба мониторинг ва аудит"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 179
  },
  {
    "id": "loihai-tavaqqufgohi-bisersatha-180",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "project",
    "nameTj": "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
    "nameRu": "Проект \"Многоуровневая парковка\"",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»"
    ],
    "headcount": 12.0,
    "positionCount": 8,
    "salary": 29400.0,
    "fmm": 29400.0,
    "totalSalary": 22180.0,
    "sourceRow": 180
  },
  {
    "id": "position-menejer-181",
    "parentId": "loihai-tavaqqufgohi-bisersatha-180",
    "type": "position",
    "nameTj": "Менеҷер",
    "nameRu": "Менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
      "Менеҷер"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6100.0,
    "fmm": 6100.0,
    "totalSalary": 5780.0,
    "sourceRow": 181
  },
  {
    "id": "position-farrosh-182",
    "parentId": "loihai-tavaqqufgohi-bisersatha-180",
    "type": "position",
    "nameTj": "Фаррош",
    "nameRu": "Уборщица",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
      "Фаррош"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2300.0,
    "fmm": 2300.0,
    "totalSalary": 2300.0,
    "sourceRow": 182
  },
  {
    "id": "bahshi-mamuriyu-hojagidorii-loihaho-183",
    "parentId": "loihai-tavaqqufgohi-bisersatha-180",
    "type": "section",
    "nameTj": "Бахши маъмурию хоҷагидории лоиҳаҳо",
    "nameRu": "Административно-хозяйственный сектор проектов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
      "Бахши маъмурию хоҷагидории лоиҳаҳо"
    ],
    "headcount": 10.0,
    "positionCount": 6,
    "salary": 21000.0,
    "fmm": 21000.0,
    "totalSalary": 14100.0,
    "sourceRow": 183
  },
  {
    "id": "position-mudiri-anbor-va-hojagi-184",
    "parentId": "bahshi-mamuriyu-hojagidorii-loihaho-183",
    "type": "position",
    "nameTj": "Мудири анбор ва хоҷагӣ",
    "nameRu": "Заведующий складом и хозяйством",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
      "Бахши маъмурию хоҷагидории лоиҳаҳо",
      "Мудири анбор ва хоҷагӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3000.0,
    "sourceRow": 184
  },
  {
    "id": "position-ofis-menejer-185",
    "parentId": "bahshi-mamuriyu-hojagidorii-loihaho-183",
    "type": "position",
    "nameTj": "Офис-менеҷер",
    "nameRu": "Офис-менеджер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
      "Бахши маъмурию хоҷагидории лоиҳаҳо",
      "Офис-менеҷер"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 185
  },
  {
    "id": "position-mutahassis-oid-ba-hm-tb-va-bs-186",
    "parentId": "bahshi-mamuriyu-hojagidorii-loihaho-183",
    "type": "position",
    "nameTj": "Мутахассис оид ба ҲМ, ТБ ва БС",
    "nameRu": "Специалист по по ОТ, ТБ и ПБ",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
      "Бахши маъмурию хоҷагидории лоиҳаҳо",
      "Мутахассис оид ба ҲМ, ТБ ва БС"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3000.0,
    "sourceRow": 186
  },
  {
    "id": "position-farrosh-187",
    "parentId": "bahshi-mamuriyu-hojagidorii-loihaho-183",
    "type": "position",
    "nameTj": "Фаррош",
    "nameRu": "Уборщица",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
      "Бахши маъмурию хоҷагидории лоиҳаҳо",
      "Фаррош"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 1500.0,
    "fmm": 3000.0,
    "totalSalary": 1700.0,
    "sourceRow": 187
  },
  {
    "id": "position-muhofiz-188",
    "parentId": "bahshi-mamuriyu-hojagidorii-loihaho-183",
    "type": "position",
    "nameTj": "Муҳофиз",
    "nameRu": "Охранник",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
      "Бахши маъмурию хоҷагидории лоиҳаҳо",
      "Муҳофиз"
    ],
    "headcount": 3.0,
    "positionCount": 1,
    "salary": 1500.0,
    "fmm": 4500.0,
    "totalSalary": 1700.0,
    "sourceRow": 188
  },
  {
    "id": "position-ronanda-189",
    "parentId": "bahshi-mamuriyu-hojagidorii-loihaho-183",
    "type": "position",
    "nameTj": "Ронанда",
    "nameRu": "Водитель",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Лоиҳаи «Таваққуфгоҳи бисёрсатҳа»",
      "Бахши маъмурию хоҷагидории лоиҳаҳо",
      "Ронанда"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 1500.0,
    "fmm": 1500.0,
    "totalSalary": 1700.0,
    "sourceRow": 189
  },
  {
    "id": "shubai-audit-va-nazorati-dohilii-loihaho-190",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "division",
    "nameTj": "Шуъбаи аудит ва назорати дохилии лоиҳаҳо",
    "nameRu": "Отдел аудита и внутреннего контроля проектов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Шуъбаи аудит ва назорати дохилии лоиҳаҳо"
    ],
    "headcount": 7.0,
    "positionCount": 4,
    "salary": 23000.0,
    "fmm": 23000.0,
    "totalSalary": 13000.0,
    "sourceRow": 190
  },
  {
    "id": "position-sardori-shuba-191",
    "parentId": "shubai-audit-va-nazorati-dohilii-loihaho-190",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Шуъбаи аудит ва назорати дохилии лоиҳаҳо",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 4000.0,
    "sourceRow": 191
  },
  {
    "id": "position-auditori-korhoi-sohtmoni-192",
    "parentId": "shubai-audit-va-nazorati-dohilii-loihaho-190",
    "type": "position",
    "nameTj": "Аудитори корҳои сохтмонӣ",
    "nameRu": "Аудитор строительных работ",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Шуъбаи аудит ва назорати дохилии лоиҳаҳо",
      "Аудитори корҳои сохтмонӣ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 192
  },
  {
    "id": "position-auditori-tehniki-193",
    "parentId": "shubai-audit-va-nazorati-dohilii-loihaho-190",
    "type": "position",
    "nameTj": "Аудитори техникӣ",
    "nameRu": "Технический аудитор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Шуъбаи аудит ва назорати дохилии лоиҳаҳо",
      "Аудитори техникӣ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 193
  },
  {
    "id": "position-auditori-moliyavi-194",
    "parentId": "shubai-audit-va-nazorati-dohilii-loihaho-190",
    "type": "position",
    "nameTj": "Аудитори молиявӣ",
    "nameRu": "Финансовый аудитор",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Шуъбаи аудит ва назорати дохилии лоиҳаҳо",
      "Аудитори молиявӣ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3000.0,
    "sourceRow": 194
  },
  {
    "id": "shubai-brokeroni-gumruki-195",
    "parentId": "departamenti-idorakunii-loihahoi-strategi-79",
    "type": "division",
    "nameTj": "Шуъбаи брокерони гумрукӣ",
    "nameRu": "Отдел таможенных брокеров",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Шуъбаи брокерони гумрукӣ"
    ],
    "headcount": 5.0,
    "positionCount": 3,
    "salary": 17500.0,
    "fmm": 17500.0,
    "totalSalary": 11780.0,
    "sourceRow": 195
  },
  {
    "id": "position-sardori-shuba-196",
    "parentId": "shubai-brokeroni-gumruki-195",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Шуъбаи брокерони гумрукӣ",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 196
  },
  {
    "id": "position-mutahassisi-kalon-oid-ba-barasmiyatdarorii-gumruki-197",
    "parentId": "shubai-brokeroni-gumruki-195",
    "type": "position",
    "nameTj": "Мутахассиси калон оид ба барасмиятдарории гумрукӣ",
    "nameRu": "Старший специалист по таможенному оформлению",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Шуъбаи брокерони гумрукӣ",
      "Мутахассиси калон оид ба барасмиятдарории гумрукӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3000.0,
    "sourceRow": 197
  },
  {
    "id": "position-mutahassis-oid-ba-barasmiyatdarorii-gumruki-198",
    "parentId": "shubai-brokeroni-gumruki-195",
    "type": "position",
    "nameTj": "Мутахассис оид ба барасмиятдарории гумрукӣ",
    "nameRu": "Специалист по таможенному оформлению",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти идоракунии лоиҳаҳои стратегӣ",
      "Шуъбаи брокерони гумрукӣ",
      "Мутахассис оид ба барасмиятдарории гумрукӣ"
    ],
    "headcount": 3.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 9000.0,
    "totalSalary": 3000.0,
    "sourceRow": 198
  },
  {
    "id": "departamenti-tehnologiyahoi-ittilooti-200",
    "parentId": "general-director",
    "type": "department",
    "nameTj": "Департаменти технологияҳои иттилоотӣ",
    "nameRu": "Департамент информационных технологий",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ"
    ],
    "headcount": 9.0,
    "positionCount": 8,
    "salary": 35300.0,
    "fmm": 35300.0,
    "totalSalary": 31680.0,
    "sourceRow": 200
  },
  {
    "id": "position-sardori-departament-201",
    "parentId": "departamenti-tehnologiyahoi-ittilooti-200",
    "type": "position",
    "nameTj": "Сардори Департамент",
    "nameRu": "Начальник Департамента",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Сардори Департамент"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6300.0,
    "fmm": 6300.0,
    "totalSalary": 6300.0,
    "sourceRow": 201
  },
  {
    "id": "shubai-tahiyai-barnomaho-202",
    "parentId": "departamenti-tehnologiyahoi-ittilooti-200",
    "type": "division",
    "nameTj": "Шуъбаи таҳияи барномаҳо",
    "nameRu": "Отдел разработки программ",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Шуъбаи таҳияи барномаҳо"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 202
  },
  {
    "id": "position-sardori-shuba-203",
    "parentId": "shubai-tahiyai-barnomaho-202",
    "type": "position",
    "nameTj": "Сардори Шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Шуъбаи таҳияи барномаҳо",
      "Сардори Шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 203
  },
  {
    "id": "bahshi-tahiyai-back-end-204",
    "parentId": "departamenti-tehnologiyahoi-ittilooti-200",
    "type": "section",
    "nameTj": "Бахши таҳияи Back-end",
    "nameRu": "Сектор Back-end разработки",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Бахши таҳияи Back-end"
    ],
    "headcount": 4.0,
    "positionCount": 3,
    "salary": 14000.0,
    "fmm": 14000.0,
    "totalSalary": 10380.0,
    "sourceRow": 204
  },
  {
    "id": "position-sardori-bahsh-205",
    "parentId": "bahshi-tahiyai-back-end-204",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Бахши таҳияи Back-end",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 205
  },
  {
    "id": "position-tahiyagari-back-end-206",
    "parentId": "bahshi-tahiyai-back-end-204",
    "type": "position",
    "nameTj": "Таҳиягари Back-end",
    "nameRu": "Back-end разработчик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Бахши таҳияи Back-end",
      "Таҳиягари Back-end"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 2880.0,
    "sourceRow": 206
  },
  {
    "id": "position-devops-muhandis-207",
    "parentId": "bahshi-tahiyai-back-end-204",
    "type": "position",
    "nameTj": "DevOps-муҳандис",
    "nameRu": "DevOps-инженер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Бахши таҳияи Back-end",
      "DevOps-муҳандис"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 2880.0,
    "sourceRow": 207
  },
  {
    "id": "bahshi-tahiyai-front-end-208",
    "parentId": "departamenti-tehnologiyahoi-ittilooti-200",
    "type": "section",
    "nameTj": "Бахши таҳияи Front-end",
    "nameRu": "Сектор Front-end разработки",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Бахши таҳияи Front-end"
    ],
    "headcount": 3.0,
    "positionCount": 3,
    "salary": 10000.0,
    "fmm": 10000.0,
    "totalSalary": 9220.0,
    "sourceRow": 208
  },
  {
    "id": "position-sardori-bahsh-209",
    "parentId": "bahshi-tahiyai-front-end-208",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Бахши таҳияи Front-end",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 209
  },
  {
    "id": "position-tahiyagari-front-end-210",
    "parentId": "bahshi-tahiyai-front-end-208",
    "type": "position",
    "nameTj": "Таҳиягари Front-end",
    "nameRu": "Front-end разработчик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Бахши таҳияи Front-end",
      "Таҳиягари Front-end"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 2880.0,
    "sourceRow": 210
  },
  {
    "id": "position-tahiyagari-junior-ui-211",
    "parentId": "bahshi-tahiyai-front-end-208",
    "type": "position",
    "nameTj": "Таҳиягари Junior UI",
    "nameRu": "Junior UI разработчик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти технологияҳои иттилоотӣ",
      "Бахши таҳияи Front-end",
      "Таҳиягари Junior UI"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2500.0,
    "fmm": 2500.0,
    "totalSalary": 1720.0,
    "sourceRow": 211
  },
  {
    "id": "filiali-jdmm-net-solyushens-dar-sh-hujand-213",
    "parentId": "general-director",
    "type": "branch",
    "nameTj": "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
    "nameRu": "Филиал ООО \"Нет Солюшенс\" в г. Худжанд",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд"
    ],
    "headcount": 9.0,
    "positionCount": 8,
    "salary": 38600.0,
    "fmm": 38600.0,
    "totalSalary": 35160.0,
    "sourceRow": 213
  },
  {
    "id": "position-direktori-filial-214",
    "parentId": "filiali-jdmm-net-solyushens-dar-sh-hujand-213",
    "type": "position",
    "nameTj": "Директори Филиал",
    "nameRu": "Директор Филиала",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Директори Филиал"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 8100.0,
    "fmm": 8100.0,
    "totalSalary": 6300.0,
    "sourceRow": 214
  },
  {
    "id": "shubai-tehniki-215",
    "parentId": "filiali-jdmm-net-solyushens-dar-sh-hujand-213",
    "type": "division",
    "nameTj": "Шуъбаи техникӣ",
    "nameRu": "Технический отдел",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Шуъбаи техникӣ"
    ],
    "headcount": 5.0,
    "positionCount": 4,
    "salary": 18500.0,
    "fmm": 18500.0,
    "totalSalary": 16160.0,
    "sourceRow": 215
  },
  {
    "id": "position-sardori-shuba-216",
    "parentId": "shubai-tehniki-215",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Шуъбаи техникӣ",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 216
  },
  {
    "id": "position-muhandis-oid-ba-istifodabarii-hathoi-aloqa-217",
    "parentId": "shubai-tehniki-215",
    "type": "position",
    "nameTj": "Муҳандис оид ба истифодабарии хатҳои алоқа",
    "nameRu": "Инженер по эксплуатации линий связи",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Шуъбаи техникӣ",
      "Муҳандис оид ба истифодабарии хатҳои алоқа"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3460.0,
    "sourceRow": 217
  },
  {
    "id": "position-muhandis-oid-ba-kor-bo-mushtarien-218",
    "parentId": "shubai-tehniki-215",
    "type": "position",
    "nameTj": "Муҳандис оид ба кор бо муштариён",
    "nameRu": "Инженер по работе с абонентами",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Шуъбаи техникӣ",
      "Муҳандис оид ба кор бо муштариён"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 7000.0,
    "totalSalary": 3460.0,
    "sourceRow": 218
  },
  {
    "id": "position-mutahassis-oid-ba-payvastkuni-219",
    "parentId": "shubai-tehniki-215",
    "type": "position",
    "nameTj": "Мутахассис оид ба пайвасткунӣ",
    "nameRu": "Специалист по подключению",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Шуъбаи техникӣ",
      "Мутахассис оид ба пайвасткунӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3460.0,
    "sourceRow": 219
  },
  {
    "id": "shubai-tijorati-220",
    "parentId": "filiali-jdmm-net-solyushens-dar-sh-hujand-213",
    "type": "division",
    "nameTj": "Шуъбаи тиҷоратӣ",
    "nameRu": "Коммерческий отдел",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Шуъбаи тиҷоратӣ"
    ],
    "headcount": 3.0,
    "positionCount": 3,
    "salary": 12000.0,
    "fmm": 12000.0,
    "totalSalary": 12700.0,
    "sourceRow": 220
  },
  {
    "id": "position-sardori-shuba-221",
    "parentId": "shubai-tijorati-220",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Шуъбаи тиҷоратӣ",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 221
  },
  {
    "id": "position-menejer-oid-ba-furush-222",
    "parentId": "shubai-tijorati-220",
    "type": "position",
    "nameTj": "Менеҷер оид ба фурӯш",
    "nameRu": "Менеджер по продажам",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Шуъбаи тиҷоратӣ",
      "Менеҷер оид ба фурӯш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 3460.0,
    "sourceRow": 222
  },
  {
    "id": "position-mutahassis-oid-ba-hizmatrasonii-mizojon-223",
    "parentId": "shubai-tijorati-220",
    "type": "position",
    "nameTj": "Мутахассис оид ба хизматрасонии мизоҷон",
    "nameRu": "Специалист по обслуживанию клиентов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Филиали ҶДММ \"Нет Солюшенс\" дар ш. Хуҷанд",
      "Шуъбаи тиҷоратӣ",
      "Мутахассис оид ба хизматрасонии мизоҷон"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3460.0,
    "sourceRow": 223
  },
  {
    "id": "departamenti-bahisobgirii-muhosibi-225",
    "parentId": "general-director",
    "type": "department",
    "nameTj": "Департаменти баҳисобгирии муҳосибӣ",
    "nameRu": "Департамент по бухгалтерскому учёту",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ"
    ],
    "headcount": 18.0,
    "positionCount": 16,
    "salary": 91000.0,
    "fmm": 91000.0,
    "totalSalary": 79780.0,
    "sourceRow": 225
  },
  {
    "id": "position-sarmuhosib-226",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "position",
    "nameTj": "Сармуҳосиб",
    "nameRu": "Главный бухгалтер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Сармуҳосиб"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 8100.0,
    "fmm": 8100.0,
    "totalSalary": 8100.0,
    "sourceRow": 226
  },
  {
    "id": "position-menejer-oid-ba-bahisobgirii-moliyai-loihaho-227",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "position",
    "nameTj": "Менеҷер оид ба баҳисобгирии молияи лоиҳаҳо",
    "nameRu": "Менеджер по финансовому учёту проектов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Менеҷер оид ба баҳисобгирии молияи лоиҳаҳо"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6940.0,
    "fmm": 6940.0,
    "totalSalary": 6940.0,
    "sourceRow": 227
  },
  {
    "id": "position-menejer-tahlilgari-moliyavi-228",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "position",
    "nameTj": "Менеҷер-таҳлилгари молиявӣ",
    "nameRu": "Финансовый менеджер-аналитик",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Менеҷер-таҳлилгари молиявӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 4040.0,
    "sourceRow": 228
  },
  {
    "id": "position-muhosibi-hisobbarobarkuni-229",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "position",
    "nameTj": "Муҳосиби ҳисоббаробаркунӣ",
    "nameRu": "Расчётный бухгалтер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Муҳосиби ҳисоббаробаркунӣ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 5780.0,
    "fmm": 11560.0,
    "totalSalary": 5780.0,
    "sourceRow": 229
  },
  {
    "id": "position-muhosibi-moddi-230",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "position",
    "nameTj": "Муҳосиби моддӣ",
    "nameRu": "Материальный бухгалтер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Муҳосиби моддӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6940.0,
    "fmm": 6940.0,
    "totalSalary": 6940.0,
    "sourceRow": 230
  },
  {
    "id": "position-muhosib-oid-ba-bahisobgirii-andoz-231",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "position",
    "nameTj": "Муҳосиб оид ба баҳисобгирии андоз",
    "nameRu": "Бухгалтер по налоговому учёту",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Муҳосиб оид ба баҳисобгирии андоз"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 6940.0,
    "fmm": 6940.0,
    "totalSalary": 6940.0,
    "sourceRow": 231
  },
  {
    "id": "position-mudiri-anbor-232",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "position",
    "nameTj": "Мудири анбор",
    "nameRu": "Заведующий складом",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Мудири анбор"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4620.0,
    "fmm": 4620.0,
    "totalSalary": 4620.0,
    "sourceRow": 232
  },
  {
    "id": "position-mutahassisi-anbor-233",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "position",
    "nameTj": "Мутахассиси анбор",
    "nameRu": "Специалист по складу",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Мутахассиси анбор"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 0,
    "sourceRow": 233
  },
  {
    "id": "position-hazinador-234",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "position",
    "nameTj": "Хазинадор",
    "nameRu": "Кассир",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Хазинадор"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5780.0,
    "fmm": 5780.0,
    "totalSalary": 5780.0,
    "sourceRow": 234
  },
  {
    "id": "shubai-bahisobgirii-muhosibii-loihaho-235",
    "parentId": "departamenti-bahisobgirii-muhosibi-225",
    "type": "division",
    "nameTj": "Шуъбаи баҳисобгирии муҳосибии лоиҳаҳо",
    "nameRu": "Отдел по бухгалтерскому учёту проектов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Шуъбаи баҳисобгирии муҳосибии лоиҳаҳо"
    ],
    "headcount": 8.0,
    "positionCount": 7,
    "salary": 33120.0,
    "fmm": 33120.0,
    "totalSalary": 30640.0,
    "sourceRow": 235
  },
  {
    "id": "position-sardori-shuba-236",
    "parentId": "shubai-bahisobgirii-muhosibii-loihaho-235",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Шуъбаи баҳисобгирии муҳосибии лоиҳаҳо",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 236
  },
  {
    "id": "position-mutahassisi-korhoi-moliyavi-237",
    "parentId": "shubai-bahisobgirii-muhosibii-loihaho-235",
    "type": "position",
    "nameTj": "Мутахассиси корҳои молиявӣ",
    "nameRu": "Специалист финансовых работ",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Шуъбаи баҳисобгирии муҳосибии лоиҳаҳо",
      "Мутахассиси корҳои молиявӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 4620.0,
    "sourceRow": 237
  },
  {
    "id": "position-muhosibi-moddi-238",
    "parentId": "shubai-bahisobgirii-muhosibii-loihaho-235",
    "type": "position",
    "nameTj": "Муҳосиби моддӣ",
    "nameRu": "Материальный бухгалтер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Шуъбаи баҳисобгирии муҳосибии лоиҳаҳо",
      "Муҳосиби моддӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 4040.0,
    "sourceRow": 238
  },
  {
    "id": "position-muhosib-oid-ba-bahisobgirii-andoz-239",
    "parentId": "shubai-bahisobgirii-muhosibii-loihaho-235",
    "type": "position",
    "nameTj": "Муҳосиб оид ба баҳисобгирии андоз",
    "nameRu": "Бухгалтер по налоговому учёту",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Шуъбаи баҳисобгирии муҳосибии лоиҳаҳо",
      "Муҳосиб оид ба баҳисобгирии андоз"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4620.0,
    "fmm": 4620.0,
    "totalSalary": 4620.0,
    "sourceRow": 239
  },
  {
    "id": "position-muhosibi-amalieti-240",
    "parentId": "shubai-bahisobgirii-muhosibii-loihaho-235",
    "type": "position",
    "nameTj": "Муҳосиби амалиётӣ",
    "nameRu": "Операционный бухгалтер",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Шуъбаи баҳисобгирии муҳосибии лоиҳаҳо",
      "Муҳосиби амалиётӣ"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 8000.0,
    "totalSalary": 4040.0,
    "sourceRow": 240
  },
  {
    "id": "position-iqtisodchi-241",
    "parentId": "shubai-bahisobgirii-muhosibii-loihaho-235",
    "type": "position",
    "nameTj": "Иқтисодчӣ",
    "nameRu": "Экономист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Шуъбаи баҳисобгирии муҳосибии лоиҳаҳо",
      "Иқтисодчӣ"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 4040.0,
    "sourceRow": 241
  },
  {
    "id": "position-hazinador-242",
    "parentId": "shubai-bahisobgirii-muhosibii-loihaho-235",
    "type": "position",
    "nameTj": "Хазинадор",
    "nameRu": "Кассир",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Департаменти баҳисобгирии муҳосибӣ",
      "Шуъбаи баҳисобгирии муҳосибии лоиҳаҳо",
      "Хазинадор"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3500.0,
    "fmm": 3500.0,
    "totalSalary": 3500.0,
    "sourceRow": 242
  },
  {
    "id": "shubai-idorakunii-hayati-kormandon-244",
    "parentId": "general-director",
    "type": "division",
    "nameTj": "Шуъбаи идоракунии ҳайати кормандон",
    "nameRu": "Отдел по управлению персоналом",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи идоракунии ҳайати кормандон"
    ],
    "headcount": 7.0,
    "positionCount": 6,
    "salary": 23100.0,
    "fmm": 23100.0,
    "totalSalary": 21960.0,
    "sourceRow": 244
  },
  {
    "id": "position-sardori-shuba-245",
    "parentId": "shubai-idorakunii-hayati-kormandon-244",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи идоракунии ҳайати кормандон",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 5780.0,
    "sourceRow": 245
  },
  {
    "id": "position-mutahassis-oid-ba-idorakunii-hayati-kormandon-246",
    "parentId": "shubai-idorakunii-hayati-kormandon-244",
    "type": "position",
    "nameTj": "Мутахассис оид ба идоракунии ҳайати кормандон",
    "nameRu": "Специалист по управлению персоналом",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи идоракунии ҳайати кормандон",
      "Мутахассис оид ба идоракунии ҳайати кормандон"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 3000.0,
    "totalSalary": 3460.0,
    "sourceRow": 246
  },
  {
    "id": "position-korguzor-247",
    "parentId": "shubai-idorakunii-hayati-kormandon-244",
    "type": "position",
    "nameTj": "Коргузор",
    "nameRu": "Делопроизводитель",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи идоракунии ҳайати кормандон",
      "Коргузор"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2300.0,
    "fmm": 2300.0,
    "totalSalary": 2300.0,
    "sourceRow": 247
  },
  {
    "id": "position-farrosh-248",
    "parentId": "shubai-idorakunii-hayati-kormandon-244",
    "type": "position",
    "nameTj": "Фаррош",
    "nameRu": "Уборщица",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи идоракунии ҳайати кормандон",
      "Фаррош"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 2300.0,
    "fmm": 2300.0,
    "totalSalary": 2300.0,
    "sourceRow": 248
  },
  {
    "id": "bahshi-idorakunii-hayati-kormandoni-loihaho-249",
    "parentId": "shubai-idorakunii-hayati-kormandon-244",
    "type": "section",
    "nameTj": "Бахши идоракунии ҳайати кормандони лоиҳаҳо",
    "nameRu": "Сектор по управлению персоналом проектов",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи идоракунии ҳайати кормандон",
      "Бахши идоракунии ҳайати кормандони лоиҳаҳо"
    ],
    "headcount": 3.0,
    "positionCount": 2,
    "salary": 10500.0,
    "fmm": 10500.0,
    "totalSalary": 8120.0,
    "sourceRow": 249
  },
  {
    "id": "position-sardori-bahsh-250",
    "parentId": "bahshi-idorakunii-hayati-kormandoni-loihaho-249",
    "type": "position",
    "nameTj": "Сардори бахш",
    "nameRu": "Начальник сектора",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи идоракунии ҳайати кормандон",
      "Бахши идоракунии ҳайати кормандони лоиҳаҳо",
      "Сардори бахш"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4500.0,
    "fmm": 4500.0,
    "totalSalary": 4620.0,
    "sourceRow": 250
  },
  {
    "id": "position-mutahassis-251",
    "parentId": "bahshi-idorakunii-hayati-kormandoni-loihaho-249",
    "type": "position",
    "nameTj": "Мутахассис",
    "nameRu": "Специалист",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи идоракунии ҳайати кормандон",
      "Бахши идоракунии ҳайати кормандони лоиҳаҳо",
      "Мутахассис"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 3500.0,
    "sourceRow": 251
  },
  {
    "id": "shubai-haridori-va-logistika-253",
    "parentId": "general-director",
    "type": "division",
    "nameTj": "Шуъбаи харидорӣ ва логистика",
    "nameRu": "Отдел закупок и логистики",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи харидорӣ ва логистика"
    ],
    "headcount": 2.0,
    "positionCount": 2,
    "salary": 9000.0,
    "fmm": 9000.0,
    "totalSalary": 8660.0,
    "sourceRow": 253
  },
  {
    "id": "position-sardori-shuba-254",
    "parentId": "shubai-haridori-va-logistika-253",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи харидорӣ ва логистика",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 4620.0,
    "sourceRow": 254
  },
  {
    "id": "position-menejer-oid-ba-harid-255",
    "parentId": "shubai-haridori-va-logistika-253",
    "type": "position",
    "nameTj": "Менеҷер оид ба харид",
    "nameRu": "Менеджер по закупу",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи харидорӣ ва логистика",
      "Менеҷер оид ба харид"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 4000.0,
    "fmm": 4000.0,
    "totalSalary": 4040.0,
    "sourceRow": 255
  },
  {
    "id": "shubai-hamgiroii-sistema-257",
    "parentId": "general-director",
    "type": "division",
    "nameTj": "Шуъбаи ҳамгироии система",
    "nameRu": "Отдел системной интеграции",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи ҳамгироии система"
    ],
    "headcount": 3.0,
    "positionCount": 2,
    "salary": 11000.0,
    "fmm": 11000.0,
    "totalSalary": 6340.0,
    "sourceRow": 257
  },
  {
    "id": "position-sardori-shuba-258",
    "parentId": "shubai-hamgiroii-sistema-257",
    "type": "position",
    "nameTj": "Сардори шуъба",
    "nameRu": "Начальник отдела",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи ҳамгироии система",
      "Сардори шуъба"
    ],
    "headcount": 1.0,
    "positionCount": 1,
    "salary": 5000.0,
    "fmm": 5000.0,
    "totalSalary": 4040.0,
    "sourceRow": 258
  },
  {
    "id": "position-mutahassisi-tehniki-oid-ba-sistemahoi-jaraenhoi-pastshi",
    "parentId": "shubai-hamgiroii-sistema-257",
    "type": "position",
    "nameTj": "Мутахассиси техникӣ оид ба системаҳои ҷараёнҳои пастшиддат",
    "nameRu": "Технический специалист по слаботочным системам",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи ҳамгироии система",
      "Мутахассиси техникӣ оид ба системаҳои ҷараёнҳои пастшиддат"
    ],
    "headcount": 2.0,
    "positionCount": 1,
    "salary": 3000.0,
    "fmm": 6000.0,
    "totalSalary": 2300.0,
    "sourceRow": 259
  },
  {
    "id": "dar-majmu-261",
    "parentId": "shubai-hamgiroii-sistema-257",
    "type": "section",
    "nameTj": "ДАР МАҶМУЪ :",
    "nameRu": "ВСЕГО",
    "path": [
      "Шӯрои нозирон",
      "Директори генералӣ",
      "Шуъбаи ҳамгироии система",
      "ДАР МАҶМУЪ :"
    ],
    "headcount": 0,
    "positionCount": 0,
    "salary": 0,
    "fmm": 0,
    "totalSalary": 0,
    "sourceRow": 261
  }
];

export const topLevelUnitNames = [
  "Департаменти тиҷоратӣ",
  "Департаменти техникӣ",
  "Департаменти идоракунии лоиҳаҳои стратегӣ",
  "Департаменти технологияҳои иттилоотӣ",
  "Филиали ҶДММ "Нет Солюшенс" дар ш. Хуҷанд",
  "Департаменти баҳисобгирии муҳосибӣ",
  "Шуъбаи идоракунии ҳайати кормандон",
  "Шуъбаи харидорӣ ва логистика",
  "Шуъбаи ҳамгироии система",
];

export const formatNumber = (value: number) =>
  value.toLocaleString("ru-RU", { maximumFractionDigits: value % 1 === 0 ? 0 : 2 });

export const formatMoney = (value: number) => `${formatNumber(value)} сомонӣ`;

export function getUnitById(id: string | null | undefined): NetsUnit | undefined {
  if (!id) return undefined;
  return units.find((unit) => unit.id === id);
}

export function getChildren(parentId: string | null): NetsUnit[] {
  return units.filter((unit) => unit.parentId === parentId);
}

export function getDescendants(parentId: string): NetsUnit[] {
  const children = getChildren(parentId);
  return children.flatMap((child) => [child, ...getDescendants(child.id)]);
}

export function getPositions(parentId?: string): NetsUnit[] {
  if (!parentId) return units.filter((unit) => unit.type === "position");
  return getDescendants(parentId).filter((unit) => unit.type === "position");
}

export function getTopLevelUnits(): NetsUnit[] {
  return topLevelUnitNames
    .map((name) => units.find((unit) => unit.parentId === "general-director" && unit.nameTj === name))
    .filter((unit): unit is NetsUnit => Boolean(unit));
}

export function getStrategicProjectsUnit(): NetsUnit | undefined {
  return units.find((unit) => unit.nameTj === "Департаменти идоракунии лоиҳаҳои стратегӣ");
}

export function getDepartmentFor(unit: NetsUnit): NetsUnit | undefined {
  const topIds = new Set(getTopLevelUnits().map((item) => item.id));
  let current: NetsUnit | undefined = unit;
  while (current) {
    if (topIds.has(current.id)) return current;
    current = getUnitById(current.parentId);
  }
  return undefined;
}

export function getDirectStructuralChildren(parentId: string): NetsUnit[] {
  return getChildren(parentId).filter((unit) => unit.type !== "position");
}

export interface PayrollStats {
  headcount: number;
  positionCount: number;
  totalSalary: number;
  averageSalary: number;
  minSalary: number;
  maxSalary: number;
}

export function getPayrollStats(): PayrollStats {
  const positions = getPositions();
  const headcount = positions.reduce((sum, item) => sum + item.headcount, 0);
  const totalSalary = positions.reduce((sum, item) => sum + item.totalSalary, 0);
  const weightedSalary = positions.reduce((sum, item) => sum + item.salary * item.headcount, 0);
  const salaries = positions.map((item) => item.salary).filter((salary) => salary > 0);
  return {
    headcount,
    positionCount: positions.length,
    totalSalary,
    averageSalary: headcount ? weightedSalary / headcount : 0,
    minSalary: salaries.length ? Math.min(...salaries) : 0,
    maxSalary: salaries.length ? Math.max(...salaries) : 0,
  };
}

export function getTypeLabel(type: NetsUnitType): string {
  const labels: Record<NetsUnitType, string> = {
    company: "Компания",
    board: "Совет",
    director: "Руководство",
    department: "Департамент",
    branch: "Филиал",
    division: "Шуъба",
    section: "Бахш",
    project: "Лоиҳа",
    subsystem: "Зернизом",
    position: "Должность",
  };
  return labels[type];
}

// Compatibility exports for the original Lovable components that are still present in the repo.
// The current route uses the NetsUnit helpers above; these adapters keep unused legacy views compilable.
export type LocationId = "hq" | "projects" | "commerce" | "technical" | "finance" | "branch";
export type CycleStageId =
  | "management"
  | "commerce"
  | "technical"
  | "projects"
  | "it"
  | "finance"
  | "support"
  | "hr";
export type SupportTrackId = "admin" | "commerce" | "technical" | "projects" | "finance" | "support";

export interface Position {
  title: string;
  count: number;
}

export interface Department {
  id: string;
  name: string;
  short?: string;
  description: string;
  locationId: LocationId;
  cycleStageId?: CycleStageId;
  supportTrackId?: SupportTrackId;
  positions: Position[];
}

export interface LocationInfo {
  id: LocationId;
  title: string;
  subtitle: string;
  physical: string;
  color: string;
  ring: string;
  badge: string;
}

export interface CycleStageInfo {
  id: CycleStageId;
  title: string;
  short: string;
  color: string;
}

export interface SupportTrackInfo {
  id: SupportTrackId;
  title: string;
  color: string;
}

export type HierarchyColorKey =
  | "executive"
  | "engineering"
  | "processing"
  | "field"
  | "water"
  | "maintenance"
  | "supply"
  | "security"
  | "ecology"
  | "admin";

export interface HierarchyNode {
  id: string;
  title: string;
  subtitle: string;
  departmentIds: string[];
  colorKey: HierarchyColorKey;
  leadTitle?: string;
  leadDepartmentId?: string;
  children?: HierarchyNode[];
}

export const locations: LocationInfo[] = [
  {
    id: "hq",
    title: "Маркази идоракунӣ",
    subtitle: "Роҳбарият ва сохторҳои марказӣ",
    physical: "Сохторҳои асосии идоракунии ҶДММ “Нет Солюшенс”.",
    color: "bg-emerald-500/10",
    ring: "ring-emerald-500/30",
    badge: "bg-emerald-50 text-emerald-800 border-emerald-200",
  },
  {
    id: "projects",
    title: "Лоиҳаҳои стратегӣ",
    subtitle: "Проекты и подсистемы",
    physical: "Департаменти идоракунии лоиҳаҳои стратегӣ.",
    color: "bg-sky-500/10",
    ring: "ring-sky-500/30",
    badge: "bg-sky-50 text-sky-800 border-sky-200",
  },
  {
    id: "commerce",
    title: "Тиҷорат",
    subtitle: "Коммерческий блок",
    physical: "Департаменти тиҷоратӣ.",
    color: "bg-teal-500/10",
    ring: "ring-teal-500/30",
    badge: "bg-teal-50 text-teal-800 border-teal-200",
  },
  {
    id: "technical",
    title: "Техникӣ ва IT",
    subtitle: "Технический и IT блок",
    physical: "Департаменти техникӣ ва Департаменти технологияҳои иттилоотӣ.",
    color: "bg-indigo-500/10",
    ring: "ring-indigo-500/30",
    badge: "bg-indigo-50 text-indigo-800 border-indigo-200",
  },
  {
    id: "finance",
    title: "Молия ва ҳисобдорӣ",
    subtitle: "Бухгалтерия и финансы",
    physical: "Департаменти баҳисобгирии муҳосибӣ.",
    color: "bg-zinc-500/10",
    ring: "ring-zinc-500/30",
    badge: "bg-zinc-50 text-zinc-800 border-zinc-200",
  },
  {
    id: "branch",
    title: "Филиал ва дастгирӣ",
    subtitle: "Филиал, HR, закупки, интеграция",
    physical: "Филиал ва дастгирии фаъолияти ширкат.",
    color: "bg-amber-500/10",
    ring: "ring-amber-500/30",
    badge: "bg-amber-50 text-amber-800 border-amber-200",
  },
];

export const cycleStages: CycleStageInfo[] = [
  { id: "management", title: "Идоракунӣ", short: "Роҳбарият", color: "from-emerald-500 to-emerald-700" },
  { id: "commerce", title: "Тиҷорат", short: "Фурӯш ва бозор", color: "from-teal-500 to-teal-700" },
  { id: "technical", title: "Техникӣ", short: "Шабака ва хизматрасонӣ", color: "from-indigo-500 to-indigo-700" },
  { id: "projects", title: "Лоиҳаҳо", short: "Стратегические проекты", color: "from-sky-500 to-sky-700" },
  { id: "it", title: "IT", short: "Технологияҳои иттилоотӣ", color: "from-cyan-500 to-cyan-700" },
  { id: "finance", title: "Молия", short: "Ҳисобдорӣ", color: "from-zinc-500 to-zinc-700" },
  { id: "support", title: "Дастгирӣ", short: "HR, харид, ҳамгироӣ", color: "from-amber-500 to-amber-700" },
  { id: "hr", title: "Кадрҳо", short: "Ҳайати кормандон", color: "from-lime-500 to-lime-700" },
];

export const supportTracks: SupportTrackInfo[] = [
  { id: "admin", title: "Идоракунӣ", color: "bg-emerald-50 border-emerald-200 text-emerald-800" },
  { id: "commerce", title: "Тиҷорат", color: "bg-teal-50 border-teal-200 text-teal-800" },
  { id: "technical", title: "Техникӣ", color: "bg-indigo-50 border-indigo-200 text-indigo-800" },
  { id: "projects", title: "Лоиҳаҳо", color: "bg-sky-50 border-sky-200 text-sky-800" },
  { id: "finance", title: "Молия", color: "bg-zinc-50 border-zinc-200 text-zinc-800" },
  { id: "support", title: "Дастгирӣ", color: "bg-amber-50 border-amber-200 text-amber-800" },
];

function legacyLocationFor(unit: NetsUnit): LocationId {
  if (unit.nameTj.includes("лоиҳа")) return "projects";
  if (unit.nameTj.includes("тиҷорат")) return "commerce";
  if (unit.nameTj.includes("техник") || unit.nameTj.includes("технология")) return "technical";
  if (unit.nameTj.includes("баҳисобгир")) return "finance";
  if (unit.nameTj.includes("Филиали") || unit.nameTj.includes("харид") || unit.nameTj.includes("ҳайати")) return "branch";
  return "hq";
}

function legacyStageFor(unit: NetsUnit): CycleStageId {
  const location = legacyLocationFor(unit);
  if (location === "projects") return "projects";
  if (location === "commerce") return "commerce";
  if (location === "technical") return unit.nameTj.includes("технология") ? "it" : "technical";
  if (location === "finance") return "finance";
  if (unit.nameTj.includes("ҳайати")) return "hr";
  if (location === "branch") return "support";
  return "management";
}

export const departments: Department[] = getTopLevelUnits().map((unit) => ({
  id: unit.id,
  name: unit.nameTj,
  short: unit.nameRu ?? undefined,
  description: unit.nameRu ?? getTypeLabel(unit.type),
  locationId: legacyLocationFor(unit),
  cycleStageId: legacyStageFor(unit),
  supportTrackId: legacyStageFor(unit) === "finance" ? "finance" : legacyStageFor(unit) === "projects" ? "projects" : "support",
  positions: getPositions(unit.id).map((position) => ({
    title: position.nameTj,
    count: position.headcount,
  })),
}));

export const hierarchyTree: HierarchyNode = {
  id: "company",
  title: "Директори генералӣ",
  subtitle: "Идоракунии умумии ҶДММ “Нет Солюшенс”.",
  departmentIds: departments.map((department) => department.id),
  colorKey: "executive",
  leadTitle: "Директори генералӣ",
  leadDepartmentId: departments[0]?.id,
  children: departments.map((department) => ({
    id: `node-${department.id}`,
    title: department.name,
    subtitle: department.description,
    departmentIds: [department.id],
    colorKey: "admin",
    leadTitle: department.name,
    leadDepartmentId: department.id,
  })),
};

export function totalHeadcount(): number {
  return getPayrollStats().headcount;
}

export function getDept(id: string): Department | undefined {
  return departments.find((department) => department.id === id);
}

export function getLocation(id: LocationId): LocationInfo {
  return locations.find((location) => location.id === id) ?? locations[0];
}

export function getStage(id: CycleStageId): CycleStageInfo {
  return cycleStages.find((stage) => stage.id === id) ?? cycleStages[0];
}

export function getSupportTrack(id: SupportTrackId): SupportTrackInfo {
  return supportTracks.find((track) => track.id === id) ?? supportTracks[0];
}

export function deptsByLocation(id: LocationId): Department[] {
  return departments.filter((department) => department.locationId === id);
}

export function deptsByStage(id: CycleStageId): Department[] {
  return departments.filter((department) => department.cycleStageId === id);
}

export function deptsBySupport(id: SupportTrackId): Department[] {
  return departments.filter((department) => department.supportTrackId === id);
}
