import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  BarChart3,
  BookOpen,
  Building2,
  FileSpreadsheet,
  Network,
  Search,
  X,
} from "lucide-react";
import {
  formatMoney,
  formatNumber,
  getChildren,
  getDepartmentFor,
  getDirectStructuralChildren,
  getPayrollStats,
  getPositions,
  getStrategicProjectsUnit,
  getTopLevelUnits,
  getTypeLabel,
  getUnitById,
  type NetsUnit,
} from "@/data/orgStructure";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Сохтори таркибии ҶДММ “Нет Солюшенс”" },
      {
        name: "description",
        content: "Интерактивная организационная структура компании Net Solutions.",
      },
      { property: "og:title", content: "Сохтори таркибии ҶДММ “Нет Солюшенс”" },
      {
        property: "og:description",
        content: "Оргсхема, департаменты, стратегические проекты, штатное расписание и HR аналитика.",
      },
    ],
  }),
  component: Index,
});

type AppTab = "org" | "departments" | "projects" | "staff" | "analytics" | "glossary";

const tabs: Array<{ id: AppTab; label: string; Icon: typeof Network }> = [
  { id: "org", label: "Оргсхема", Icon: Network },
  { id: "departments", label: "Департаменты", Icon: Building2 },
  { id: "projects", label: "Стратегические проекты", Icon: Network },
  { id: "staff", label: "Штатное расписание", Icon: FileSpreadsheet },
  { id: "analytics", label: "HR аналитика", Icon: BarChart3 },
  { id: "glossary", label: "Глоссарий", Icon: BookOpen },
];

function Index() {
  const [tab, setTab] = useState<AppTab>("org");
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const stats = getPayrollStats();

  useEffect(() => {
    const handler = (event: Event) => {
      const id = (event as CustomEvent<string>).detail;
      if (id) setSelectedUnitId(id);
    };
    window.addEventListener("select-unit", handler);
    return () => window.removeEventListener("select-unit", handler);
  }, []);

  return (
    <div className="min-h-screen bg-white text-zinc-900">
      <div className="mx-auto max-w-[1600px] px-4 py-4 sm:px-6 sm:py-6">
        <header className="mb-4 border-b border-zinc-200 pb-4">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
            <div className="min-w-0">
              <div className="text-[11px] uppercase tracking-[0.18em] text-emerald-700">
                Net Solutions
              </div>
              <h1 className="mt-1 text-2xl font-semibold leading-tight text-zinc-950 sm:text-3xl">
                Сохтори таркибии ҶДММ “Нет Солюшенс”
              </h1>
              <p className="mt-1 max-w-2xl text-sm text-zinc-600">
                Интерактивная организационная структура компании
              </p>
            </div>
            <KpiStrip stats={stats} />
          </div>

          <nav className="mt-4 overflow-x-auto">
            <div className="inline-flex min-w-max gap-1 rounded-lg border border-zinc-200 bg-zinc-50 p-1">
              {tabs.map(({ id, label, Icon }) => {
                const active = tab === id;
                return (
                  <button
                    key={id}
                    onClick={() => setTab(id)}
                    className={`flex items-center gap-1.5 rounded-md px-3 py-2 text-sm transition ${
                      active
                        ? "bg-white text-emerald-700 shadow-sm ring-1 ring-emerald-200"
                        : "text-zinc-600 hover:bg-white hover:text-zinc-950"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {label}
                  </button>
                );
              })}
            </div>
          </nav>
        </header>

        <main>
          {tab === "org" && <OrgChart onSelect={setSelectedUnitId} />}
          {tab === "departments" && <DepartmentsView onSelect={setSelectedUnitId} />}
          {tab === "projects" && <StrategicProjectsView onSelect={setSelectedUnitId} />}
          {tab === "staff" && <StaffTable onSelect={setSelectedUnitId} />}
          {tab === "analytics" && <HrAnalytics onSelect={setSelectedUnitId} />}
          {tab === "glossary" && <Glossary />}
        </main>
      </div>

      <DetailsPanel unitId={selectedUnitId} onClose={() => setSelectedUnitId(null)} />
    </div>
  );
}

function KpiStrip({ stats }: { stats: ReturnType<typeof getPayrollStats> }) {
  return (
    <section className="grid grid-cols-2 gap-2 lg:grid-cols-4">
      <Kpi label="Штатных единиц" value={formatNumber(stats.headcount)} />
      <Kpi label="Должностей" value={formatNumber(stats.positionCount)} />
      <Kpi label="Фонд оплаты" value={formatMoney(stats.totalSalary)} />
      <Kpi label="Основных блоков" value="9" />
    </section>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-[150px] rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2">
      <div className="text-[10px] uppercase tracking-wide text-zinc-500">{label}</div>
      <div className="mt-1 text-lg font-semibold text-zinc-950">{value}</div>
    </div>
  );
}

function OrgChart({ onSelect }: { onSelect: (id: string) => void }) {
  const topUnits = getTopLevelUnits();
  const board = getUnitById("board");
  const director = getUnitById("general-director");

  return (
    <section className="rounded-lg border border-zinc-200 bg-white">
      <div className="border-b border-zinc-200 px-4 py-3">
        <h2 className="text-base font-semibold text-zinc-950">Общая оргсхема</h2>
        <p className="mt-1 text-sm text-zinc-600">
          Основные блоки показаны на верхнем уровне; должности открываются в карточке деталей.
        </p>
      </div>
      <div className="overflow-x-auto p-4">
        <div className="min-w-[1320px]">
          <div className="flex flex-col items-center">
            {board && <ChartNode unit={board} tone="dark" onSelect={onSelect} />}
            <Connector height={28} />
            {director && <ChartNode unit={director} tone="red" onSelect={onSelect} />}
            <Connector height={28} />
            <div className="h-px w-[1180px] bg-red-400" />
            <div className="grid w-full grid-cols-9 gap-3 pt-5">
              {topUnits.map((unit) => (
                <div key={unit.id} className="flex flex-col items-center">
                  <Connector height={22} />
                  <ChartNode unit={unit} tone="green" onSelect={onSelect} />
                  <div className="mt-3 flex w-full flex-col gap-2">
                    {getDirectStructuralChildren(unit.id)
                      .slice(0, 7)
                      .map((child) => (
                        <ChartNode key={child.id} unit={child} tone="gray" onSelect={onSelect} compact />
                      ))}
                    {getDirectStructuralChildren(unit.id).length > 7 && (
                      <button
                        onClick={() => onSelect(unit.id)}
                        className="rounded-md border border-dashed border-zinc-300 px-2 py-2 text-xs text-zinc-500 hover:bg-zinc-50"
                      >
                        + ещё {getDirectStructuralChildren(unit.id).length - 7}
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Connector({ height }: { height: number }) {
  return <div className="w-px bg-red-400" style={{ height }} />;
}

function ChartNode({
  unit,
  tone,
  compact,
  onSelect,
}: {
  unit: NetsUnit;
  tone: "dark" | "red" | "green" | "gray";
  compact?: boolean;
  onSelect: (id: string) => void;
}) {
  const classes = {
    dark: "border-zinc-800 bg-zinc-900 text-white",
    red: "border-red-400 bg-white text-zinc-950",
    green: "border-emerald-500 bg-white text-zinc-950",
    gray: "border-zinc-300 bg-white text-zinc-900",
  }[tone];

  return (
    <button
      onClick={() => onSelect(unit.id)}
      className={`w-full rounded-lg border px-3 text-center shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${classes} ${
        compact ? "min-h-[62px] py-2" : "min-h-[82px] py-3"
      }`}
    >
      <div className={`font-semibold leading-snug ${compact ? "text-[11px]" : "text-sm"}`}>
        {unit.nameTj}
      </div>
      {unit.nameRu && (
        <div className={`mt-1 leading-snug opacity-70 ${compact ? "text-[10px]" : "text-xs"}`}>
          {unit.nameRu}
        </div>
      )}
      {unit.type !== "board" && (
        <div className="mt-1 text-[10px] opacity-70">
          {formatNumber(unit.headcount)} ед. · {formatNumber(unit.positionCount)} долж.
        </div>
      )}
    </button>
  );
}

function DepartmentsView({ onSelect }: { onSelect: (id: string) => void }) {
  return (
    <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
      {getTopLevelUnits().map((unit) => {
        const children = getDirectStructuralChildren(unit.id);
        return (
          <button
            key={unit.id}
            onClick={() => onSelect(unit.id)}
            className="rounded-lg border border-zinc-200 bg-white p-4 text-left transition hover:border-emerald-400 hover:shadow-sm"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-base font-semibold text-zinc-950">{unit.nameTj}</h3>
                {unit.nameRu && <p className="mt-1 text-sm text-zinc-500">{unit.nameRu}</p>}
              </div>
              <span className="rounded-md border border-emerald-200 bg-emerald-50 px-2 py-1 text-xs text-emerald-700">
                {getTypeLabel(unit.type)}
              </span>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-sm">
              <MiniStat label="Ед." value={formatNumber(unit.headcount)} />
              <MiniStat label="Долж." value={formatNumber(unit.positionCount)} />
              <MiniStat label="Фонд" value={formatMoney(unit.totalSalary)} />
            </div>
            <div className="mt-4 text-xs text-zinc-500">
              {children.slice(0, 5).map((child) => child.nameTj).join(" · ")}
              {children.length > 5 && ` · + ещё ${children.length - 5}`}
            </div>
          </button>
        );
      })}
    </section>
  );
}

function StrategicProjectsView({ onSelect }: { onSelect: (id: string) => void }) {
  const root = getStrategicProjectsUnit();
  if (!root) return null;
  const blocks = getDirectStructuralChildren(root.id);

  return (
    <section className="rounded-lg border border-zinc-200 bg-white">
      <div className="border-b border-zinc-200 px-4 py-3">
        <h2 className="text-base font-semibold text-zinc-950">
          Структура Департамента стратегических проектов
        </h2>
        <p className="mt-1 text-sm text-zinc-600">
          Проекты, подсистемы и службы департамента вынесены в отдельную рабочую схему.
        </p>
      </div>
      <div className="overflow-x-auto p-4">
        <div className="min-w-[1100px]">
          <div className="mx-auto max-w-md">
            <ChartNode unit={root} tone="green" onSelect={onSelect} />
          </div>
          <div className="mt-6 grid grid-cols-4 gap-3">
            {blocks.map((block) => (
              <div key={block.id} className="flex flex-col gap-2">
                <ChartNode unit={block} tone={block.type === "project" ? "green" : "gray"} onSelect={onSelect} />
                {getDirectStructuralChildren(block.id).slice(0, 5).map((child) => (
                  <ChartNode key={child.id} unit={child} tone="gray" compact onSelect={onSelect} />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function StaffTable({ onSelect }: { onSelect: (id: string) => void }) {
  const [query, setQuery] = useState("");
  const [departmentId, setDepartmentId] = useState("all");
  const [sortKey, setSortKey] = useState<"path" | "headcount" | "salary" | "fmm" | "totalSalary">("path");
  const departments = getTopLevelUnits();

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return getPositions()
      .filter((position) => {
        const department = getDepartmentFor(position);
        if (departmentId !== "all" && department?.id !== departmentId) return false;
        if (!q) return true;
        return [position.nameTj, position.nameRu, position.path.join(" ")]
          .filter(Boolean)
          .some((value) => String(value).toLowerCase().includes(q));
      })
      .sort((a, b) => {
        if (sortKey === "path") return a.path.join(" / ").localeCompare(b.path.join(" / "));
        return b[sortKey] - a[sortKey];
      });
  }, [query, departmentId, sortKey]);

  return (
    <section className="rounded-lg border border-zinc-200 bg-white">
      <div className="border-b border-zinc-200 p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <h2 className="text-base font-semibold text-zinc-950">Штатное расписание</h2>
            <p className="mt-1 text-sm text-zinc-600">
              Найдено строк: {formatNumber(rows.length)}
            </p>
          </div>
          <div className="grid gap-2 sm:grid-cols-3">
            <label className="relative">
              <Search className="pointer-events-none absolute left-2 top-2.5 h-4 w-4 text-zinc-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Поиск"
                className="h-9 w-full rounded-md border border-zinc-300 pl-8 pr-3 text-sm outline-none focus:border-emerald-500"
              />
            </label>
            <select
              value={departmentId}
              onChange={(event) => setDepartmentId(event.target.value)}
              className="h-9 rounded-md border border-zinc-300 px-3 text-sm outline-none focus:border-emerald-500"
            >
              <option value="all">Все департаменты</option>
              {departments.map((department) => (
                <option key={department.id} value={department.id}>
                  {department.nameTj}
                </option>
              ))}
            </select>
            <select
              value={sortKey}
              onChange={(event) => setSortKey(event.target.value as typeof sortKey)}
              className="h-9 rounded-md border border-zinc-300 px-3 text-sm outline-none focus:border-emerald-500"
            >
              <option value="path">По структуре</option>
              <option value="headcount">По количеству</option>
              <option value="salary">По окладу</option>
              <option value="fmm">По ФММ</option>
              <option value="totalSalary">По итогу</option>
            </select>
          </div>
        </div>
      </div>
      <div className="max-h-[650px] overflow-auto">
        <table className="w-full min-w-[1100px] text-left text-sm">
          <thead className="sticky top-0 z-10 bg-zinc-50 text-[11px] uppercase tracking-wide text-zinc-500">
            <tr>
              <th className="px-3 py-2">Путь</th>
              <th className="px-3 py-2">Департамент</th>
              <th className="px-3 py-2">Должность TJ</th>
              <th className="px-3 py-2">Должность RU</th>
              <th className="px-3 py-2 text-right">Кол-во</th>
              <th className="px-3 py-2 text-right">Оклад</th>
              <th className="px-3 py-2 text-right">ФММ</th>
              <th className="px-3 py-2 text-right">Итого</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((position) => {
              const department = getDepartmentFor(position);
              return (
                <tr
                  key={position.id}
                  onClick={() => onSelect(position.id)}
                  className="cursor-pointer border-t border-zinc-100 hover:bg-emerald-50/50"
                >
                  <td className="max-w-[300px] px-3 py-2 text-xs text-zinc-500">
                    {position.path.slice(2, -1).join(" / ")}
                  </td>
                  <td className="px-3 py-2 text-xs text-zinc-600">{department?.nameTj}</td>
                  <td className="px-3 py-2 font-medium text-zinc-950">{position.nameTj}</td>
                  <td className="px-3 py-2 text-zinc-600">{position.nameRu}</td>
                  <td className="px-3 py-2 text-right">{formatNumber(position.headcount)}</td>
                  <td className="px-3 py-2 text-right">{formatMoney(position.salary)}</td>
                  <td className="px-3 py-2 text-right">{formatMoney(position.fmm)}</td>
                  <td className="px-3 py-2 text-right font-medium">{formatMoney(position.totalSalary)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function HrAnalytics({ onSelect }: { onSelect: (id: string) => void }) {
  const stats = getPayrollStats();
  const topByHeadcount = getTopLevelUnits().slice().sort((a, b) => b.headcount - a.headcount);
  const topByPayroll = getTopLevelUnits().slice().sort((a, b) => b.totalSalary - a.totalSalary);

  return (
    <section className="space-y-4">
      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-6">
        <Kpi label="Единиц" value={formatNumber(stats.headcount)} />
        <Kpi label="Должностей" value={formatNumber(stats.positionCount)} />
        <Kpi label="Фонд оплаты" value={formatMoney(stats.totalSalary)} />
        <Kpi label="Средний оклад" value={formatMoney(stats.averageSalary)} />
        <Kpi label="Мин. оклад" value={formatMoney(stats.minSalary)} />
        <Kpi label="Макс. оклад" value={formatMoney(stats.maxSalary)} />
      </div>
      <div className="grid gap-4 xl:grid-cols-2">
        <BarList title="Распределение по численности" items={topByHeadcount} valueKey="headcount" onSelect={onSelect} />
        <BarList title="Распределение по фонду оплаты" items={topByPayroll} valueKey="totalSalary" money onSelect={onSelect} />
      </div>
    </section>
  );
}

function BarList({
  title,
  items,
  valueKey,
  money,
  onSelect,
}: {
  title: string;
  items: NetsUnit[];
  valueKey: "headcount" | "totalSalary";
  money?: boolean;
  onSelect: (id: string) => void;
}) {
  const max = Math.max(...items.map((item) => item[valueKey]), 1);
  return (
    <div className="rounded-lg border border-zinc-200 bg-white p-4">
      <h3 className="text-base font-semibold text-zinc-950">{title}</h3>
      <div className="mt-4 space-y-3">
        {items.map((item) => (
          <button key={item.id} onClick={() => onSelect(item.id)} className="block w-full text-left">
            <div className="mb-1 flex items-center justify-between gap-3 text-xs">
              <span className="truncate font-medium text-zinc-700">{item.nameTj}</span>
              <span className="shrink-0 text-zinc-500">
                {money ? formatMoney(item[valueKey]) : formatNumber(item[valueKey])}
              </span>
            </div>
            <div className="h-2 rounded-full bg-zinc-100">
              <div
                className="h-2 rounded-full bg-emerald-500"
                style={{ width: `${Math.max(3, (item[valueKey] / max) * 100)}%` }}
              />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function Glossary() {
  const items = [
    ["Департамент", "крупный функциональный блок компании."],
    ["Шуъба", "отдел внутри структуры."],
    ["Бахш", "сектор или участок внутри отдела."],
    ["Лоиҳа", "проектное направление."],
    ["Зернизом", "подсистема внутри проекта или направления."],
    ["Шумора", "количество штатных единиц."],
    ["Маоши вазифавӣ", "должностной оклад."],
    ["ФММ", "расчёт фонда оплаты."],
  ];
  return (
    <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
      {items.map(([term, description]) => (
        <div key={term} className="rounded-lg border border-zinc-200 bg-white p-4">
          <h3 className="font-semibold text-zinc-950">{term}</h3>
          <p className="mt-2 text-sm text-zinc-600">{description}</p>
        </div>
      ))}
    </section>
  );
}

function DetailsPanel({ unitId, onClose }: { unitId: string | null; onClose: () => void }) {
  const unit = getUnitById(unitId);
  const positions = unit ? (unit.type === "position" ? [unit] : getPositions(unit.id)) : [];
  const children = unit ? getChildren(unit.id).filter((child) => child.type !== "position") : [];
  const parent = getUnitById(unit?.parentId);

  if (!unit) return null;

  return (
    <aside className="fixed inset-y-0 right-0 z-50 flex w-full max-w-xl flex-col border-l border-zinc-200 bg-white shadow-2xl">
      <div className="flex items-start justify-between gap-4 border-b border-zinc-200 p-4">
        <div>
          <div className="text-xs uppercase tracking-wide text-emerald-700">{getTypeLabel(unit.type)}</div>
          <h2 className="mt-1 text-lg font-semibold text-zinc-950">{unit.nameTj}</h2>
          {unit.nameRu && <p className="mt-1 text-sm text-zinc-600">{unit.nameRu}</p>}
        </div>
        <button onClick={onClose} className="rounded-md p-2 text-zinc-500 hover:bg-zinc-100">
          <X className="h-5 w-5" />
        </button>
      </div>
      <div className="flex-1 overflow-auto p-4">
        <div className="grid grid-cols-2 gap-2">
          <MiniStat label="Родитель" value={parent?.nameTj ?? "—"} />
          <MiniStat label="Штатных единиц" value={formatNumber(unit.headcount)} />
          <MiniStat label="Должностей" value={formatNumber(unit.positionCount)} />
          <MiniStat label="Оклад" value={formatMoney(unit.salary)} />
          <MiniStat label="ФММ" value={formatMoney(unit.fmm)} />
          <MiniStat label="Итого" value={formatMoney(unit.totalSalary)} />
        </div>
        <div className="mt-4 rounded-lg border border-zinc-200 bg-zinc-50 p-3 text-xs text-zinc-600">
          {unit.path.join(" / ")}
        </div>

        {children.length > 0 && (
          <div className="mt-5">
            <h3 className="text-sm font-semibold text-zinc-950">Дочерние подразделения</h3>
            <div className="mt-2 space-y-2">
              {children.map((child) => (
                <button
                  key={child.id}
                  onClick={() => {
                    onClose();
                    requestAnimationFrame(() => {
                      window.dispatchEvent(new CustomEvent("select-unit", { detail: child.id }));
                    });
                  }}
                  className="flex w-full items-center justify-between gap-3 rounded-md border border-zinc-200 px-3 py-2 text-left text-sm hover:border-emerald-400"
                >
                  <span>{child.nameTj}</span>
                  <span className="text-xs text-zinc-500">{formatNumber(child.headcount)} ед.</span>
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-5">
          <h3 className="text-sm font-semibold text-zinc-950">Должности</h3>
          <div className="mt-2 overflow-x-auto rounded-lg border border-zinc-200">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="bg-zinc-50 text-left text-[11px] uppercase tracking-wide text-zinc-500">
                <tr>
                  <th className="px-3 py-2">Должность TJ</th>
                  <th className="px-3 py-2">Должность RU</th>
                  <th className="px-3 py-2 text-right">Кол-во</th>
                  <th className="px-3 py-2 text-right">Оклад</th>
                  <th className="px-3 py-2 text-right">Итого</th>
                </tr>
              </thead>
              <tbody>
                {positions.map((position) => (
                  <tr key={position.id} className="border-t border-zinc-100">
                    <td className="px-3 py-2 font-medium text-zinc-950">{position.nameTj}</td>
                    <td className="px-3 py-2 text-zinc-600">{position.nameRu}</td>
                    <td className="px-3 py-2 text-right">{formatNumber(position.headcount)}</td>
                    <td className="px-3 py-2 text-right">{formatMoney(position.salary)}</td>
                    <td className="px-3 py-2 text-right">{formatMoney(position.totalSalary)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </aside>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-zinc-200 bg-zinc-50 px-3 py-2">
      <div className="text-[10px] uppercase tracking-wide text-zinc-500">{label}</div>
      <div className="mt-1 break-words text-sm font-semibold text-zinc-950">{value}</div>
    </div>
  );
}
